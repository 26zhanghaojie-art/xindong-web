/**
 * Personal employee contributions only. Rates are percentages, e.g. 8 means 8%.
 * This module supplies no regional rates or assumed bases: callers must provide
 * every field explicitly, including zero when an item does not apply.
 */
const numeric = value => (typeof value === 'number'
  || (typeof value === 'string' && value.trim() !== '')) && Number.isFinite(Number(value));
const FIELDS = {
  socialBase: ['社保缴费基数', 1_000_000_000],
  housingBase: ['公积金缴存基数', 1_000_000_000],
  pensionRate: ['个人养老保险比例', 100],
  medicalRate: ['个人医疗保险比例', 100],
  unemploymentRate: ['个人失业保险比例', 100],
  housingRate: ['个人公积金比例', 100],
  socialFixed: ['个人每月固定附加扣款', 1_000_000_000],
};

// Integer decimal arithmetic keeps half-cent rounding independent from binary
// floating-point products. All validated amounts fit safely into Number cents.
function decimal(value) {
  const [mantissa, exponent = '0'] = Number(value).toString().toLowerCase().split('e');
  const [whole, fraction = ''] = mantissa.split('.');
  let units = BigInt(whole + fraction);
  let scale = fraction.length - Number(exponent);
  if (scale < 0) { units *= 10n ** BigInt(-scale); scale = 0; }
  return { units, scale };
}

function roundedRatio(units, scale) {
  const divisor = 10n ** BigInt(scale);
  return (units + divisor / 2n) / divisor;
}

function componentCents(base, percent) {
  const b = decimal(base), p = decimal(percent);
  // base * percentage / 100 yuan = base * percentage cents.
  return roundedRatio(b.units * p.units, b.scale + p.scale);
}

export function calculateContributions(input = {}) {
  const errors = {};
  for (const [field, [label, maximum]] of Object.entries(FIELDS)) {
    const value = input?.[field];
    if (!numeric(value) || Number(value) < 0 || Number(value) > maximum)
      errors[field] = maximum === 100 ? `${label}须填写 0 到 100 之间的百分数` : `${label}须填写 0 到 10 亿元之间的金额`;
  }
  if (Object.keys(errors).length) {
    const error = new RangeError(Object.values(errors).join('；'));
    error.errors = errors;
    throw error;
  }
  const fixed = decimal(input.socialFixed);
  const cents = {
    pension: componentCents(input.socialBase, input.pensionRate),
    medical: componentCents(input.socialBase, input.medicalRate),
    unemployment: componentCents(input.socialBase, input.unemploymentRate),
    housing: componentCents(input.housingBase, input.housingRate),
    fixed: roundedRatio(fixed.units * 100n, fixed.scale),
  };
  const total = Object.values(cents).reduce((sum, value) => sum + value, 0n);
  return { ...Object.fromEntries(Object.entries(cents).map(([key, value]) => [key, Number(value) / 100])), social: Number(total) / 100 };
}
