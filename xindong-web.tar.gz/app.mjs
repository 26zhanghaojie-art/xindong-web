import { estimateSalary, validateProfile, getDayProgress } from './engine.mjs';
import { sendProfile } from './delivery.mjs';
import { getCalendarDay, countWorkdays } from './calendar.mjs';
import { allocateExpenses } from './expenses.mjs';
import { createCalendarEditor } from './calendar-editor.mjs';
import { mountRelief } from './relief.mjs';
import {loadPreferences,normalizePreferences,defaultPreferences,preferenceKey,roundTimeToStep,stepTime,applyPositivePreset} from './preferences.mjs';

const $ = (id) => document.getElementById(id);
const currency = (n) => `¥ ${Number(n).toLocaleString('zh-CN', {minimumFractionDigits:2,maximumFractionDigits:2})}`;
const storeKey = 'xindong-profile-v1';
const goalsKey = 'xindong-goals-v1';
const defaultGoals = [{emoji:'☕',name:'一杯瑞幸',price:10},{emoji:'🍱',name:'一顿午饭',price:20},{emoji:'🍰',name:'下午茶',price:18},{emoji:'🚇',name:'往返通勤',price:12},{emoji:'🍲',name:'一顿好好吃的晚饭',price:35}];
const demoProfile = {calendarMode:'china',workdaysMode:'calendar',nickname:'小薪',salaryMode:'estimate',gross:12000,social:1500,special:1000,workdays:22,start:'09:00',end:'18:00',lunchEnabled:false,lunchStart:'12:00',lunchEnd:'13:00',weekdays:[1,2,3,4,5]};
let profile = null;
let goals = structuredClone(defaultGoals);
let demo = false;
let demoStarted = performance.now();
let preferences=loadPreferences({getItem:key=>localStorage.getItem(key)});
let relief = null;
let moneyHidden = preferences.hideByDefault;
let isPinned = false;
let lastGoalState = '';
let lastStatsState = '';
let editorGoals = [];
let toastTimer;
let draggedGoal = null;
let loginBusy = false;
let draftOverrides = {};
try { const p = JSON.parse(localStorage.getItem(storeKey)); if (validateProfile(p).valid) profile = {...p,calendarMode:p.calendarMode||'custom',workdaysMode:p.workdaysMode||'manual'}; } catch {}
try { const g = JSON.parse(localStorage.getItem(goalsKey)); if (validGoals(g)) goals = g; } catch {}

function validGoals(list) { return Array.isArray(list) && list.length > 0 && list.length <= 20 && list.every(g=>typeof g.name==='string' && g.name.trim() && g.name.length<=32 && Number.isFinite(g.price) && g.price>0 && g.price<=1000000 && (g.emoji===undefined || typeof g.emoji==='string') && (g.period===undefined || ['daily','monthly'].includes(g.period))); }
function toast(message) { clearTimeout(toastTimer); $('toast').textContent=message; $('toast').hidden=false; toastTimer=setTimeout(()=>$('toast').hidden=true,3200); }
function element(tag, className, text) { const e=document.createElement(tag); if(className)e.className=className; if(text!==undefined)e.textContent=text; return e; }
function show(id) { if(!$(id).open)$(id).showModal(); }
function currentProfile() { return demo ? demoProfile : profile; }
function currentTime() { return demo ? new Date(new Date(2026,10,3,13,35).getTime()+performance.now()-demoStarted) : new Date(); }
function timeParts(seconds) { const s=Math.max(0,Math.floor(seconds)); return [Math.floor(s/3600),Math.floor(s/60)%60,s%60].map(n=>String(n).padStart(2,'0')); }
function setCountdown(seconds) { const parts=timeParts(seconds); $('countdown').replaceChildren(document.createTextNode(parts[0]),element('span','',':'),document.createTextNode(parts[1]),element('span','',':'),document.createTextNode(parts[2])); }
function duration(seconds) { const m=Math.ceil(seconds/60); return m<60?`${m} 分钟`:`${Math.floor(m/60)} 小时 ${m%60} 分钟`; }
function goalStages(earned) {
  const p=currentProfile()||demoProfile;
  const date=currentProfile()?getDayProgress(p,currentTime()).shiftDate:currentTime();
  return allocateExpenses(goals,{date,profile:p,earned});
}
function renderGoals(earned) {
  const stages=goalStages(earned), nextIndex=stages.findIndex(g=>!g.done&&!g.notDue);
  const signature=JSON.stringify(stages.map(g=>[g.name,g.emoji,g.price,g.dailyPrice,g.threshold,g.period,g.done,g.notDue,g.allocationActive]))+nextIndex+moneyHidden+preferences.tone;
  if(signature===lastGoalState) return;
  lastGoalState=signature;
  $('goalsCount').textContent=String(goals.length).padStart(2,'0');
  $('goalsList').replaceChildren(); $('obtainedList').replaceChildren();
  stages.forEach((g,i)=>{
    const row=element('div',`goal-row${i===nextIndex?' current':''}`), name=element('div','goal-name'), text=element('div');
    text.append(element('strong','',g.name),element('small','',g.period==='monthly'?`每月 ¥${g.price} · 今日 ¥${g.dailyPrice.toFixed(2)}`:`每天 ${currency(g.dailyPrice)}`));
    name.append(element('span','goal-emoji',g.emoji||'✦'),text);
    row.append(name,element('span','goal-threshold',`¥ ${g.threshold.toLocaleString('zh-CN')}`),element('span',`goal-state ${g.done?'complete':i===nextIndex?'current':''}`,g.notDue?'今日无需分摊':!g.allocationActive?'休息日':g.done?'✓ 已覆盖':i===nextIndex?'正在积攒':'等待解锁'));
    $('goalsList').append(row);
    if(g.done){const card=element('div','obtained-item');card.append(element('span','obtained-check','✓'),element('span','emoji',g.emoji||'✦'),element('strong','',g.name+(g.period==='monthly'?' · 今日份额':'')),element('small','',`收入已覆盖 ¥${g.dailyPrice.toFixed(2)}`));$('obtainedList').append(card);}
  });
  const done=stages.filter(g=>g.done), covered=done.reduce((a,g)=>a+g.dailyPrice,0);
  if(!done.length){const active=stages.some(g=>g.allocationActive),first=stages.find(g=>!g.notDue);const empty=element('div','empty-obtained');empty.append(element('span','','✳'),element('div','',active?`第一项开销，需要 ¥${first?.threshold||0}。`:'今天休息，给生活留点时间。'),element('div','',active?'开销还没覆盖，工资正赶来。':'今日不计薪，也不分摊月度账单。'));$('obtainedList').append(empty);}
  $('coveredTotal').textContent=moneyHidden?'¥ •••':currency(covered);
  $('coveredCaption').textContent=done.length?`今天的收入，已覆盖 ${done.length} 项生活开销`:'收入覆盖的开销会显示在这里';
}
function render() {
  const now=currentTime(),p=currentProfile();
  $('todayDate').textContent=now.toLocaleDateString('zh-CN',{year:'numeric',month:'long',day:'numeric',weekday:'long'});
  $('demoBadge').hidden=!demo;
  $('demoToggle').textContent=demo?'退出演示':'查看演示';
  if(!p){if(lastStatsState!==`empty:${moneyHidden}`)startEmpty();renderGoals(0);return;}
  const s=getDayProgress(p,now), amount=s.earned.toFixed(preferences.precision).split('.');
  $('earnedInteger').textContent=moneyHidden?'•••':Number(amount[0]).toLocaleString('zh-CN');
  $('earnedDecimal').textContent=moneyHidden?'':`.${amount[1]}`;
  $('speedText').textContent=moneyHidden?'金额已隐藏':s.status==='working'?`每秒 + ¥ ${s.perSecond.toFixed(4)}，工资继续算`:`计薪速度 ¥ ${s.perSecond.toFixed(4)} / 秒`;
  const labels={working:'● 计薪中',before:'○ 还未开工',finished:preferences.tone==='spicy'?'✓ 下班了，工作请止步':'✓ 今日已收工',off:'○ 今天休息'};
  $('workStatus').textContent=labels[s.status];
  $('countdownLabel').textContent=s.status==='before'?'距离上班':s.status==='off'?'给生活留点时间':s.status==='finished'?'今日班次已结束':'距离下班';
  setCountdown(s.status==='before'?(new Date(s.shiftStart)-now)/1000:(s.status==='off'||s.status==='finished')?0:(new Date(s.shiftEnd)-now)/1000);
  $('progressText').textContent=`${(s.progress*100).toFixed(1)}%`;
  $('workProgress').style.width=`${s.progress*100}%`;
  $('workProgressTrack').setAttribute('aria-valuenow',(s.progress*100).toFixed(1));
  $('workedHours').textContent=`已计薪 ${(s.workedSeconds/3600).toFixed(2)} / ${(s.totalSeconds/3600).toFixed(2)} 小时`;
  $('shiftHours').textContent=`${p.start} — ${p.end}${p.end<p.start?' 次日':''}`;
  const calendarDate=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
  $('shiftDateNote').hidden=s.shiftDate===calendarDate;
  $('shiftDateNote').textContent=s.shiftDate===calendarDate?'':`当前计薪班次：${s.shiftDate}（跨午夜）`;
  const stages=goalStages(s.earned), next=stages.find(g=>!g.done&&!g.notDue), total=stages.at(-1)?.threshold||0;
  $('nextReward').textContent=s.emptyMonth?'本月全部休息，暂不计薪或分摊月度账单。':moneyHidden?'薪资金额已隐藏，点击金额旁的按钮即可显示。':next?(s.daily+1e-8<next.threshold?`下一个：${next.name}。累计门槛 ¥${next.threshold}，超过今日满勤收入。`:s.status==='working'?`再计薪 ${duration((next.threshold-s.earned)/s.perSecond)}，就覆盖「${next.name}${next.period==='monthly'?'的今日份额':''}」。`:`距离「${next.name}」还差 ${currency(next.threshold-s.earned)}。`):`今日清单全部覆盖！额外积攒 ${currency(s.earned-total)}。`;
  const statsState=JSON.stringify(p)+moneyHidden+demo+s.shiftDate+preferences.tone;
  if(statsState!==lastStatsState){
    lastStatsState=statsState;
    $('greeting').textContent=`${p.nickname}，${toneCopy().greeting}`;
    $('avatar')?.remove();
    $('profileButton').textContent=p.nickname.slice(0,1);
    $('netLabel').textContent=p.salaryMode!=='manual'?'税后月薪 · 年均估算':'税后月薪 · 实际填写';
    $('monthlySalary').textContent=moneyHidden?'¥ •••':currency(s.net);
    $('dailySalary').textContent=moneyHidden?'¥ •••':currency(s.daily);
    $('hourlySalary').textContent=moneyHidden?'¥ •••':currency(s.perSecond*3600);
    $('estimateNote').textContent=p.salaryMode!=='manual'?'固定月薪假设，以实际工资条为准':'使用你填写的实际到手工资';
    $('workdaysNote').textContent=`按${p.workdaysMode==='calendar'?'当月日历':'每月'} ${s.workdays} 个工作日`;
    $('hoursNote').textContent=`每日计薪 ${(s.totalSeconds/3600).toFixed(1)} 小时`;
  }
  $('calendarNote').textContent=`${p.calendarMode==='china'?'中国节假日及调休':'自定义工作日'} · ${s.calendarName||''} · 本月 ${countWorkdays(now.getFullYear(),now.getMonth(),p)} 个工作日${s.calendarKnown===false?' · ⚠ 本年度官方日历未加载，暂按周一至周五估算':''}`;
  renderGoals(s.earned);
}

const form=$('profileForm');
const pickerControls={};
for(const container of form.querySelectorAll('[data-time-picker]')){
  const key=container.dataset.timePicker,label=key==='start'?'上班':'下班',hour=document.createElement('select'),minute=document.createElement('select');
  hour.setAttribute('aria-label',`${label}小时`);minute.setAttribute('aria-label',`${label}分钟`);
  for(let h=0;h<24;h++){const option=element('option','',String(h).padStart(2,'0'));option.value=String(h).padStart(2,'0');hour.append(option);}
  for(const m of [0,10,20,30,40,50,60]){const value=String(m).padStart(2,'0'),option=element('option','',m===60?'60 → 下一小时':value);option.value=value;minute.append(option);}
  container.append(hour,element('span','',':'),minute);pickerControls[key]={hour,minute};
  const sync=()=>{const carry=minute.value==='60',normalized=stepTime(hour.value,minute.value);setPickerTime(key,normalized);if(carry)toast(`已进位到 ${normalized}${normalized==='00:00'?'（跨午夜）':''}`);updateForm();};hour.onchange=minute.onchange=sync;
}
function setPickerTime(key,value){const[h,m]=value.split(':');pickerControls[key].hour.value=h;pickerControls[key].minute.value=m;form.elements[key].value=value;}

for(const [day,label] of [[1,'一'],[2,'二'],[3,'三'],[4,'四'],[5,'五'],[6,'六'],[0,'日']]){
  const l=element('label'),i=document.createElement('input');i.type='checkbox';i.name='weekday';i.value=String(day);i.checked=day>0&&day<6;l.append(i,element('span','',label));$('weekdayOptions').append(l);
}
const contributionFields=['socialBase','housingBase','pensionRate','medicalRate','unemploymentRate','housingRate','socialFixed'];
function readProfile(){
  const data=new FormData(form),mode=data.get('salaryMode');
  const p={nickname:String(data.get('nickname')||'').trim(),salaryMode:mode,calendarMode:data.get('calendarMode'),workdaysMode:data.get('workdaysMode'),dateOverrides:{...draftOverrides},workdays:data.get('workdays'),start:data.get('start'),end:data.get('end'),lunchEnabled:false,weekdays:data.getAll('weekday').map(Number)};
  if(mode==='manual')p.net=data.get('net');else{p.gross=data.get('gross');p.special=data.get('special')||0;if(mode==='contributions')for(const key of contributionFields)p[key]=data.get(key);else p.social=data.get('social')||0;}
  return p;
}
function draftNet(){try{const p=readProfile();return p.salaryMode==='manual'?Number(p.net):estimateSalary(p).net;}catch{return NaN;}}
const monthEditor=createCalendarEditor({root:$('monthCalendar'),getProfile:readProfile,getOverrides:()=>draftOverrides,getNet:draftNet,onChange:map=>{draftOverrides=map;form.elements.workdaysMode.value='calendar';updateForm();}});
function updateForm(){
  const mode=form.elements.salaryMode.value;
  for(const [selector,visible]of [['[data-estimated]',mode!=='manual'],['[data-amount]',mode==='estimate'],['[data-contributions]',mode==='contributions'],['[data-manual]',mode==='manual']])document.querySelectorAll(selector).forEach(e=>{e.hidden=!visible;e.querySelectorAll('input').forEach(i=>i.disabled=!visible);});
  form.elements.gross.required=mode!=='manual';form.elements.net.required=mode==='manual';for(const key of contributionFields)form.elements[key].required=mode==='contributions';
  const calendarProfile={calendarMode:form.elements.calendarMode.value,weekdays:[...form.querySelectorAll('[name=weekday]:checked')].map(i=>Number(i.value)),dateOverrides:draftOverrides};
  const today=new Date();let days=0;try{days=countWorkdays(today.getFullYear(),today.getMonth(),calendarProfile);}catch{}
  const auto=form.elements.workdaysMode.value==='calendar';form.elements.workdays.readOnly=auto;form.elements.workdays.min=auto?'0':'1';if(auto)form.elements.workdays.value=days;
  $('customWeekdays').hidden=calendarProfile.calendarMode==='china';
  const total=new Date(today.getFullYear(),today.getMonth()+1,0).getDate();
  $('calendarPreview').textContent=`本月 ${total} 天，休息 ${total-days} 天，工作 ${days} 天。日薪与月度账单按实际工作日分摊；展开月历可自由修改。`;
  try{const p=readProfile(),result=mode==='manual'?{net:Number(p.net)}:estimateSalary(p);if(!Number.isFinite(result.net)||result.net<0||mode==='manual'&&result.net===0)throw Error();
    const details=result.contributions?`养老 ${currency(result.contributions.pension)}＋医保 ${currency(result.contributions.medical)}＋失业 ${currency(result.contributions.unemployment)}＋公积金 ${currency(result.contributions.housing)}＋定额 ${currency(result.contributions.fixed)}。个人合计 ${currency(result.social)}。\n`:'';
    const divisor=days>0?Number(p.workdays):0;$('salaryPreview').textContent=details+(mode==='manual'?`实际税后月薪 ${currency(result.net)}`:`预计年均月到手 ${currency(result.net)} · 月均个税 ${currency(result.monthlyTax)}（固定月薪估算，非当月实发）`)+` · 本月日薪 ${currency(divisor>0?result.net/divisor:0)}`;
  }catch(error){$('salaryPreview').textContent=mode==='contributions'?'填写两个缴费基数及全部个人比例后，显示扣款明细和税后结果。失业比例请按工资条核对。':'填写薪资和扣除项后，这里显示税后结果。';}
  monthEditor.render();
}
function openProfile(){
  form.reset();
  const p=profile||{calendarMode:'china',workdaysMode:'calendar',nickname:'',salaryMode:'estimate',gross:'',social:0,special:0,net:'',workdays:22,start:'09:00',end:'18:00',lunchEnabled:false,lunchStart:'12:00',lunchEnd:'13:00',weekdays:[1,2,3,4,5]};draftOverrides={...(p.dateOverrides||{})};
  for(const[key,value]of Object.entries(p)){if(key==='weekdays')form.querySelectorAll('[name=weekday]').forEach(i=>i.checked=value.includes(Number(i.value)));else if(form.elements[key])form.elements[key].value=value;}
  const changed=[];for(const key of ['start','end']){const before=p[key],rounded=roundTimeToStep(before);setPickerTime(key,rounded);if(rounded!==before)changed.push(`${before} → ${rounded}`);}
  $('timeRoundingNote').hidden=!changed.length;$('timeRoundingNote').textContent=changed.length?`旧时间已在表单中对齐到十分钟：${changed.join('，')}。保存后生效。`:'';
  $('monthCalendarDetails').open=false;$('profileError').textContent='';updateForm();monthEditor.resetMonth();show('profileDialog');refreshLoginSettings();
}
form.addEventListener('input',e=>{if(!$('monthCalendar').contains(e.target))updateForm();});
form.addEventListener('submit',(e)=>{e.preventDefault();const p=readProfile(),v=validateProfile(p);if(!v.valid){$('profileError').textContent=Object.values(v.errors).join('；');return;}try{localStorage.setItem(storeKey,JSON.stringify(p));}catch{$('profileError').textContent='本机保存失败，请检查存储空间后重试。';return;}profile=p;demo=false;lastStatsState='';$('profileDialog').close();render();toast('已保存到本机，开始按你的作息计算。');});
function startDemo(){demo=true;demoStarted=performance.now();lastStatsState='';$('profileDialog').close();render();}
$('previewDemo').onclick=startDemo;
$('demoToggle').onclick=()=>{if(demo){demo=false;lastStatsState='';if(!profile){openProfile();startEmpty();}else render();}else startDemo();};
function startEmpty(){
  lastStatsState=`empty:${moneyHidden}`;
  const reset={
    earnedInteger:moneyHidden?'•••':'0',earnedDecimal:moneyHidden?'':'.'+'0'.repeat(preferences.precision),
    demoToggle:'查看演示',workStatus:'等待开始',profileButton:'薪',
    greeting:'先填工资，算清这一天。',calendarNote:'支持中国法定节假日及调休 · 到点自动计算',
    nextReward:'你的下一项生活开销，正在路上。',speedText:'设置工资，开始看见收入',
    progressText:'0%',countdownLabel:'等待设置工资',workedHours:'已计薪 0 小时',
    shiftHours:'尚未设置作息',netLabel:'税后月薪',estimateNote:'填写后自动计算',
    workdaysNote:'按月工作日折算',hoursNote:'按每日计薪时长折算',
    monthlySalary:'¥ —',dailySalary:'¥ —',hourlySalary:'¥ —',
  };
  for(const [id,value]of Object.entries(reset))$(id).textContent=value;
  $('demoBadge').hidden=true;$('workProgress').style.width='0%';
  $('workProgressTrack').setAttribute('aria-valuenow','0');
  $('shiftDateNote').hidden=true;$('shiftDateNote').textContent='';
  setCountdown(0);renderGoals(0);
}
['settingsNav','profileButton','editSalary'].forEach(id=>$(id).onclick=openProfile);
$('todayNav').onclick=()=>window.scrollTo({top:0,behavior:'smooth'});
$('hideMoney').onclick=()=>{moneyHidden=!moneyHidden;$('hideMoney').setAttribute('aria-label',moneyHidden?'显示薪资':'隐藏薪资');$('hideMoney').title=moneyHidden?'显示薪资':'隐藏薪资';$('hideMoney').setAttribute('aria-pressed',String(moneyHidden));render();};
$('pinButton').onclick=async()=>{if(!window.desktop){toast('置顶功能可在桌面版中使用。');return;}try{isPinned=await window.desktop.setAlwaysOnTop(!isPinned);$('pinButton').classList.toggle('on',isPinned);toast(isPinned?'窗口已置顶':'已取消置顶');}catch{toast('窗口置顶未成功，请重试。');}};

function renderGoalEditor(){
  $('goalsEditor').replaceChildren();
  editorGoals.forEach((g,index)=>{
    const row=element('div','goal-edit-row');row.dataset.index=String(index);const handle=element('span','drag-handle','⋮⋮');handle.title='按住这里，上下拖动调整优先级';handle.draggable=true;handle.ondragstart=e=>{draggedGoal=index;e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',String(index));};row.ondragover=e=>{e.preventDefault();e.dataTransfer.dropEffect='move';row.classList.add('drag-target');};row.ondragleave=()=>row.classList.remove('drag-target');row.ondrop=e=>{e.preventDefault();if(draggedGoal!==null&&draggedGoal!==index){const [moved]=editorGoals.splice(draggedGoal,1);editorGoals.splice(index,0,moved);renderGoalEditor();}draggedGoal=null;row.classList.remove('drag-target');};handle.ondragend=()=>{draggedGoal=null;document.querySelectorAll('.drag-target').forEach(r=>r.classList.remove('drag-target'));};row.append(handle);
    for(const [key,label,type]of [['emoji','图标','text'],['name','开销名称','text'],['price','金额','number']]){const input=document.createElement('input');input.type=type;input.value=g[key]||'';input.setAttribute('aria-label',`第 ${index+1} 项${label}`);if(type==='number'){input.min='.01';input.step='.01';input.max='1000000';}else input.maxLength=key==='emoji'?8:32;input.oninput=()=>{editorGoals[index][key]=key==='price'?Number(input.value):input.value;};row.append(input);}
    const period=document.createElement('select');period.setAttribute('aria-label',`第 ${index+1} 项周期`);for(const [value,label]of [['daily','每天'],['monthly','每月']]){const option=element('option','',label);option.value=value;period.append(option);}period.value=g.period||'daily';period.onchange=()=>editorGoals[index].period=period.value;row.append(period);const actions=element('div','goal-edit-controls');
    for(const [label,aria,fn,disabled]of [['↑','上移',()=>{[editorGoals[index-1],editorGoals[index]]=[editorGoals[index],editorGoals[index-1]];},index===0],['↓','下移',()=>{[editorGoals[index+1],editorGoals[index]]=[editorGoals[index],editorGoals[index+1]];},index===editorGoals.length-1],['×','删除',()=>{editorGoals.splice(index,1);},false]]){const button=element('button','',label);button.setAttribute('aria-label',`${aria}第 ${index+1} 项`);button.disabled=disabled;button.onclick=()=>{fn();renderGoalEditor();};actions.append(button);}
    row.append(actions);$('goalsEditor').append(row);
  });
}
function openGoals(){const now=currentTime(),p=currentProfile()||demoProfile,shiftDate=new Date(`${getDayProgress(p,now).shiftDate}T12:00:00`);$('allocationNote').textContent=`当前班次所在 ${shiftDate.getMonth()+1} 月 ${countWorkdays(shiftDate.getFullYear(),shiftDate.getMonth(),p)} 个工作日 · 月度金额自动平均分摊，分角差额优先分配到月初工作日。`;editorGoals=structuredClone(goals);$('goalsError').textContent='';renderGoalEditor();show('goalsDialog');}
['goalsNav','editGoals'].forEach(id=>$(id).onclick=openGoals);
$('addGoal').onclick=()=>{if(editorGoals.length>=20){$('goalsError').textContent='最多可以添加 20 项开销。';return;}editorGoals.push({emoji:'✨',name:'',price:10,period:'daily'});renderGoalEditor();};
for(const [id,goal]of [['addMortgage',{emoji:'🏠',name:'房贷',price:3000,period:'monthly'}],['addCarLoan',{emoji:'🚗',name:'车贷',price:1500,period:'monthly'}]])$(id).onclick=()=>{if(editorGoals.length>=20){$('goalsError').textContent='最多可以添加 20 项开销。';return;}editorGoals.unshift({...goal});renderGoalEditor();};
$('saveGoals').onclick=()=>{const cleaned=editorGoals.map(g=>({...g,name:g.name.trim(),price:Math.round(g.price*100)/100}));if(!validGoals(cleaned)){$('goalsError').textContent='请保留至少一项，填写名称和大于 0、不超过 100 万元的金额。';return;}try{localStorage.setItem(goalsKey,JSON.stringify(cleaned));}catch{$('goalsError').textContent='本机保存失败，请稍后重试。';return;}goals=cleaned;lastGoalState='';$('goalsDialog').close();render();toast('开销清单已更新。');};

function openSubmission(){
  if(demo||!profile){toast('请先填写自己的信息，演示数据不能提交。');openProfile();return;}
  const p=profile,s=getDayProgress(p),estimate=p.salaryMode==='manual'?null:estimateSalary(p);$('submissionSummary').replaceChildren();
  const rows=[['用途','了解用户情况，改进产品'],['昵称',p.nickname],['工资输入方式',p.salaryMode==='manual'?'实际税后':p.salaryMode==='contributions'?'税前＋缴费基数比例':'税前＋扣款金额'],...(estimate?[['税前月薪',currency(estimate.gross)],['个人五险一金合计 / 月',currency(estimate.social)],['专项附加扣除 / 月',currency(estimate.special)],['估算年均月个税',currency(estimate.monthlyTax)]]:[]),['税后月薪',`${currency(s.net)}${estimate?'（年均估算）':''}`],['税后日薪',currency(s.daily)],['税后时薪',currency(s.perSecond*3600)],['月工作日',`${s.workdays} 天（${p.workdaysMode==='calendar'?'日历自动':'手填'}）`],['工作日历',p.calendarMode==='china'?'中国法定日历＋自选日期':'自定义工作日＋自选日期'],['上下班',`${p.start} — ${p.end}`],['计薪规则','按上下班时段计算']];
  for(const[label,value]of rows){const item=element('div');item.append(element('span','',label),element('strong','',value));$('submissionSummary').append(item);}
  $('submitConsent').checked=false;$('submissionStatus').textContent='';show('sendDialog');
}
$('sendNav').onclick=openSubmission;$('mobileSend').onclick=openSubmission;
$('editCalendar').onclick=()=>{openProfile();$('monthCalendarDetails').open=true;$('monthCalendarDetails').scrollIntoView({block:'center',behavior:'smooth'});};
$('submitProfile').onclick=async()=>{if(!$('submitConsent').checked){$('submissionStatus').textContent='请先阅读发送内容并勾选同意。';return;}const button=$('submitProfile');button.disabled=true;button.textContent='正在提交…';$('submissionStatus').textContent='';try{const result=await sendProfile(profile,{consent:true});$('submissionStatus').textContent=result.message||'邮件服务已接受提交；实际送达以收件箱为准。';if(result.ok || result.status==='accepted'){$('submitConsent').checked=false;}}catch(error){$('submissionStatus').textContent=error.message||'提交失败，请检查网络后重试。';}finally{button.disabled=false;button.textContent='确认提交';}};
async function refreshLoginSettings(){if(!window.desktop?.getLoginSettings)return;$('loginSetting').hidden=false;try{const result=await window.desktop.getLoginSettings();$('launchAtLogin').checked=result.openAtLogin;$('launchAtLogin').disabled=!result.supported;$('loginMessage').textContent=result.message||'';}catch{$('loginMessage').textContent='自动启动状态暂时无法读取。';}}
$('launchAtLogin').onchange=async()=>{if(loginBusy)return;loginBusy=true;$('launchAtLogin').disabled=true;try{const result=await window.desktop.setLaunchAtLogin($('launchAtLogin').checked);$('launchAtLogin').checked=result.openAtLogin;$('loginMessage').textContent=result.message;}catch(error){$('loginMessage').textContent=error.message;$('launchAtLogin').checked=false;}finally{loginBusy=false;$('launchAtLogin').disabled=false;}};
$('calculationInfo').onclick=()=>show('infoDialog');
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>$(b.dataset.close).close());
document.querySelectorAll('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}}));

function toneCopy(){return ({spicy:{headline:'精神已下班，工资请继续。',greeting:'人去干饭，工资站岗。',sidebar:'工牌在线，本人待机。',footer:'下班了，工作请止步。'},dry:{headline:'人在工位，精神待机。',greeting:'打工归打工，生活归我。',sidebar:'班可以上，鸡汤免了。',footer:'工牌下线，本人上线。'},quiet:{headline:'按自己的节奏，等下班。',greeting:'今天的收入，慢慢覆盖生活。',sidebar:'给生活留点时间。',footer:'今日收工，剩下是你的时间。'},confident:{headline:'裁我，就是裁大动脉。',greeting:'我的付出，值得被看见。',sidebar:'这家公司，有我算它有福。',footer:'功劳给自己，生活也给自己。'},lamb:{headline:'今天太棒了，先夸夸我！',greeting:'能量有限，先照顾自己。',sidebar:'今天的小羊，值得一朵小花。',footer:'做完一点，也值得夸夸自己。'},none:{headline:'今日计薪',greeting:'按作息自动计算。',sidebar:'薪资与日常开销',footer:''}})[preferences.tone];}
function applyPreferences(){
  document.documentElement.dataset.theme=preferences.theme;document.documentElement.dataset.density=preferences.density;document.documentElement.dataset.layout=preferences.layout;document.documentElement.dataset.companion=preferences.companion;
  const copy=toneCopy();$('mainHeadline').textContent=copy.headline;$('sidebarMotto').textContent=copy.sidebar;$('footerMotto').textContent=copy.footer;$('footerMotto').hidden=!copy.footer;
  const mascot=$('heroMascot');mascot.hidden=preferences.companion==='none';
  if(!mascot.hidden)mascot.src=`./assets/mascot-${preferences.companion}.png`;
  relief?.setPersonality({tone:preferences.tone,companion:preferences.companion});
  $('hideMoney').setAttribute('aria-label',moneyHidden?'显示薪资':'隐藏薪资');$('hideMoney').setAttribute('aria-pressed',String(moneyHidden));
  lastStatsState='';lastGoalState='';
}
const preferenceForm=$('personalizeForm');
function fillPreferences(value){for(const [key,v]of Object.entries(value)){const control=preferenceForm.elements[key];if(!control)continue;if(key==='hideByDefault')control.checked=v;else control.value=String(v);}}
function readPreferencesDraft(){const data=new FormData(preferenceForm);return normalizePreferences({...Object.fromEntries(data),hideByDefault:data.has('hideByDefault')});}
function openPreferences(){fillPreferences(preferences);$('preferencesError').textContent='';show('personalizeDialog');}
$('personalizeButton').onclick=$('personalizeNav').onclick=openPreferences;
$('resetPreferences').onclick=()=>fillPreferences(defaultPreferences);
preferenceForm.querySelectorAll('[data-positive-preset]').forEach(button=>button.onclick=()=>{fillPreferences(applyPositivePreset(readPreferencesDraft(),button.dataset.positivePreset));$('preferencesError').textContent='已选好这一套，保存后生效。也可以继续自由搭配。';});
preferenceForm.onsubmit=e=>{e.preventDefault();const next=readPreferencesDraft();try{localStorage.setItem(preferenceKey,JSON.stringify(next));}catch{$('preferencesError').textContent='本机保存失败，请重试。';return;}if(next.hideByDefault!==preferences.hideByDefault)moneyHidden=next.hideByDefault;preferences=next;applyPreferences();$('personalizeDialog').close();render();toast('就按你的来。');};
applyPreferences();
relief=mountRelief({root:$('reliefRoot'),notify:toast});
applyPreferences();
$('reliefNav').onclick=()=>$('reliefRoot').scrollIntoView({behavior:'smooth',block:'start'});
$('pinButton').hidden=!window.desktop;

if(new URLSearchParams(location.search).get('demo')==='1')startDemo();else if(!profile)openProfile();
render();setInterval(render,100);
