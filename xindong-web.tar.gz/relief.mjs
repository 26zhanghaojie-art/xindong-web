/** A local-only, non-monetary outlet. This module never reads the salary profile. */
import { clearAtmosphere, tapAtmosphere, sampleAtmosphere } from './relief-atmosphere.mjs';
export const RELIEF_STORAGE_KEY = 'xindong-relief-v1';
export const RELIEF_MAX_EVENTS = 20_000;
export const RELIEF_RETENTION_DAYS = 90;
const DAY = 86_400_000;
const CHINA_OFFSET = 8 * 3_600_000;
const MOODS = Object.freeze({ stress: '压力比较大', annoyed: '有点烦', play: '纯粹好玩', bored: '无聊' });
const DEFAULT_SETTINGS = Object.freeze({ skin: 'woodfish', sound: false, motion: 'light' });
let mountId = 0;

function validTimestamp(value) {
  return typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 && value < 8_640_000_000_000_000 - CHINA_OFFSET;
}

/** Records always use Beijing time, even if the browser's local timezone changes. */
export function reliefDateKey(timestamp) {
  if (!validTimestamp(timestamp)) throw new RangeError('无效点击时间');
  return new Date(timestamp + CHINA_OFFSET).toISOString().slice(0, 10);
}

function dateTimestamp(date) {
  if (typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new RangeError('无效记录日期');
  const value = Date.parse(`${date}T00:00:00+08:00`);
  if (!validTimestamp(value) || reliefDateKey(value) !== date) throw new RangeError('无效记录日期');
  return value;
}

export function shiftReliefDate(date, days) {
  if (!Number.isInteger(days) || Math.abs(days) > 3660) throw new RangeError('无效日期间隔');
  return reliefDateKey(dateTimestamp(date) + days * DAY);
}

function slotFor(timestamp) {
  const date = reliefDateKey(timestamp), d = new Date(timestamp + CHINA_OFFSET);
  const minute = d.getUTCHours() * 60 + (d.getUTCMinutes() < 30 ? 0 : 30);
  const time = m => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
  return { key: `${date}T${time(minute)}`, date, minute, label: `${time(minute)}—${time(minute + 30)}` };
}

function cutoffFor(now) {
  return dateTimestamp(shiftReliefDate(reliefDateKey(now), -(RELIEF_RETENTION_DAYS - 1)));
}

function plainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    && [Object.prototype, null].includes(Object.getPrototypeOf(value));
}

/** Strictly copy supported fields; preserve repeated timestamps as distinct clicks. */
export function normalizeReliefState(raw, now = Date.now()) {
  if (!validTimestamp(now)) throw new RangeError('无效当前时间');
  const source = plainObject(raw) && raw.version === 1 ? raw : {};
  const cutoff = cutoffFor(now);
  const events = (Array.isArray(source.events) ? source.events : [])
    .filter(value => validTimestamp(value) && value >= cutoff && value <= now)
    .sort((a, b) => a - b).slice(-RELIEF_MAX_EVENTS);
  const slots = new Set(events.map(value => slotFor(value).key));
  const annotations = {};
  if (plainObject(source.annotations)) {
    for (const [key, value] of Object.entries(source.annotations)) {
      if (!slots.has(key) || !plainObject(value)) continue;
      const mood = Object.hasOwn(MOODS, value.mood) ? value.mood : '';
      const note = typeof value.note === 'string' ? value.note.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, 120) : '';
      if (mood || note) annotations[key] = { mood, note };
    }
  }
  const settings = plainObject(source.settings) ? source.settings : {};
  return {
    version: 1, events, annotations,
    settings: {
      skin: ['woodfish', 'keycap'].includes(settings.skin) ? settings.skin : DEFAULT_SETTINGS.skin,
      sound: settings.sound === true,
      motion: ['light', 'full', 'off'].includes(settings.motion) ? settings.motion : DEFAULT_SETTINGS.motion,
    },
  };
}

export function addReliefEvent(state, timestamp, now = timestamp) {
  if (!validTimestamp(now) || !validTimestamp(timestamp) || timestamp > now || timestamp < cutoffFor(now))
    throw new RangeError('点击时间不在有效记录范围内');
  const clean = normalizeReliefState(state, now);
  return normalizeReliefState({ ...clean, events: [...clean.events, timestamp] }, now);
}

/** Non-empty half-hour groups, in chronological order, with an inclusive date range. */
export function groupReliefEvents(events, { fromDate, toDate = fromDate } = {}) {
  if (!Array.isArray(events)) throw new TypeError('点击记录必须是数组');
  if (fromDate !== undefined) {
    dateTimestamp(fromDate); dateTimestamp(toDate);
    if (fromDate > toDate) throw new RangeError('日期范围无效');
  }
  const groups = new Map();
  for (const timestamp of events) {
    if (!validTimestamp(timestamp)) continue;
    const slot = slotFor(timestamp);
    if (fromDate !== undefined && (slot.date < fromDate || slot.date > toDate)) continue;
    if (!groups.has(slot.key)) groups.set(slot.key, { ...slot, count: 0 });
    groups.get(slot.key).count++;
  }
  return [...groups.values()].sort((a, b) => a.key.localeCompare(b.key));
}

export function mountRelief({ root, notify, personality = {} } = {}) {
  if (!root || typeof root.append !== 'function') throw new TypeError('请提供解压区挂载容器');
  const doc = root.ownerDocument, win = doc.defaultView, id = `relief-${++mountId}`;
  const make = (tag, className, text) => {
    const node = doc.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  const button = (text, className = 'secondary-button') => { const b = make('button', className, text); b.type = 'button'; return b; };
  const select = (items, label) => {
    const field = make('select'); field.setAttribute('aria-label', label);
    for (const [value, text] of items) { const option = make('option', '', text); option.value = value; field.append(option); }
    return field;
  };
  const labelled = (text, field) => { const label = make('label', '', text); label.append(field); return label; };
  let state, loadIssue = '', disposed = false, audioContext, soundFailureShown = false;
  let selectedSlot = '', rangeMode = 'today', chosenDate = reliefDateKey(Date.now()), pendingDelete = null;
  let atmosphere = clearAtmosphere(), atmosphereTimer = null, calm = false;
  let voice = { tone: 'spicy', companion: 'horse' };
  let clearGeneration = 0;
  const timers = new Set(), downloadUrls = new Set();
  try { state = normalizeReliefState(JSON.parse(win.localStorage.getItem(RELIEF_STORAGE_KEY))); }
  catch { state = normalizeReliefState(null); loadIssue = '暂时无法读取本地解压记录。本次仍可使用，保存失败时会提示。'; }

  const section = make('section', 'relief-panel'); section.setAttribute('aria-labelledby', `${id}-title`);
  const heading = make('div', 'relief-heading'), headingText = make('div');
  headingText.append(make('div', 'eyebrow', '情绪缓冲区'));
  const title = make('h2', '', '敲走班味'); title.id = `${id}-title`;
  const headingNote = make('p', 'relief-note', '工资慢慢赚，怨气先敲散。');
  headingText.append(title, headingNote);
  const countButton = button('', 'relief-count text-button');
  heading.append(headingText, countButton);
  const stage = make('div', 'relief-stage');
  const clouds = make('div', 'relief-clouds'); clouds.setAttribute('aria-hidden', 'true');
  for (let i = 0; i < 8; i++) clouds.append(make('span', `relief-cloud relief-cloud-${i}`));
  const confetti = make('div', 'relief-confetti'); confetti.setAttribute('aria-hidden', 'true');
  for (let i = 0; i < 8; i++) confetti.append(make('i', `relief-confetti-piece relief-confetti-${i}`));
  const hit = button('', 'relief-hit'); hit.setAttribute('aria-label', '敲走班味，每次记录一次，虚拟加一元，不计入收入');
  const object = make('span', 'relief-object'); object.setAttribute('aria-hidden', 'true');
  const illustration = make('img', 'relief-woodfish-image'); illustration.src = './assets/relief-woodfish.png'; illustration.alt = ''; illustration.width = 320; illustration.height = 320; illustration.draggable = false; object.append(illustration);
  const objectLabel = make('span', 'relief-object-label', '敲'); object.append(objectLabel);
  hit.append(object, make('span', 'relief-hit-caption', '敲一下，松口气'));
  stage.append(clouds, hit, confetti);
  const atmosphereCaption = make('p', 'relief-atmosphere-caption', '敲得快，云团会变浓；停一停，也会慢慢散。');
  const releaseActions = make('div', 'relief-release-actions');
  const release = button('清空怨气', 'primary-button relief-release');
  const records = button('查看记录', 'secondary-button relief-records');
  releaseActions.append(release, records);
  const releaseFeedback = make('p', 'relief-release-feedback'); releaseFeedback.setAttribute('role', 'status');
  const releaseNote = make('p', 'relief-note relief-release-note', '只清空画面，敲击记录与感受备注会保留。');
  const warning = make('p', 'relief-note relief-disclaimer', '+1 RMB 仅为虚拟解压效果，不增加实际收入，也不解锁账单。');
  const settings = make('div', 'relief-settings');
  const skin = select([['woodfish', '电子木鱼'], ['keycap', '回车键']], '解压按钮外观');
  const motion = select([['light', '轻动效'], ['full', '明显动效'], ['off', '关闭动效']], '解压飘字动效');
  const sound = make('input'); sound.type = 'checkbox';
  const soundLabel = labelled('轻短点击音', sound); soundLabel.className = 'check-label';
  settings.append(labelled('按钮外观', skin), labelled('飘字动效', motion), soundLabel);
  const motionNote = make('p', 'relief-note');
  const status = make('p', 'relief-status'); status.setAttribute('role', 'status'); status.textContent = loadIssue;
  section.append(heading, stage, atmosphereCaption, releaseActions, releaseFeedback, releaseNote, warning, settings, motionNote, status);

  const dialog = make('dialog', 'relief-dialog'); dialog.setAttribute('aria-labelledby', `${id}-records-title`);
  const modalHead = make('div', 'modal-head');
  const recordTitle = make('h2', '', '班味记录'); recordTitle.id = `${id}-records-title`;
  const close = button('×', 'close-button'); close.setAttribute('aria-label', '关闭解压记录');
  modalHead.append(recordTitle, close);
  const explanation = make('p', 'relief-note', '这里记录你什么时候敲得多，不自动判断压力大小。你可以给某个时段标记自己的感受。');
  const toolbar = make('div', 'relief-toolbar');
  const range = select([['today', '今天'], ['week', '近 7 天'], ['date', '按日期查看']], '解压记录范围'); range.className = 'relief-range';
  const dateInput = make('input'); dateInput.type = 'date'; dateInput.setAttribute('aria-label', '查看记录日期');
  const dateLabel = labelled('记录日期', dateInput);
  toolbar.append(labelled('查看范围', range), dateLabel);
  const summary = make('p', 'relief-summary'); summary.setAttribute('role', 'status');
  const concentration = make('p', 'relief-concentration');
  const bars = make('div', 'relief-bars'); bars.setAttribute('aria-label', '半小时点击分布');
  const slotEditor = make('div', 'relief-slot-editor');
  const logList = make('div', 'relief-log-list');
  const retention = make('p', 'relief-note', '只保存在当前浏览器。最近 90 天、最多 20,000 次，超出后自动移除最旧记录及对应标记。时间按北京时间显示。');
  const actions = make('div', 'relief-actions');
  const exportButton = button('导出全部 JSON'), deleteDay = button('删除当天记录'), deleteAll = button('删除全部记录');
  deleteDay.classList.add('danger-button'); deleteAll.classList.add('danger-button');
  actions.append(exportButton, deleteDay, deleteAll);
  const confirmBox = make('div', 'relief-confirm'); confirmBox.hidden = true; confirmBox.setAttribute('role', 'group');
  const confirmText = make('p'); confirmText.id = `${id}-confirm`; confirmBox.setAttribute('aria-labelledby', confirmText.id);
  const confirmDelete = button('确认删除', 'primary-button danger-button'), cancelDelete = button('取消');
  confirmBox.append(confirmText, confirmDelete, cancelDelete);
  const recordStatus = make('p', 'relief-status'); recordStatus.setAttribute('role', 'status');
  dialog.append(modalHead, explanation, toolbar, summary, concentration, bars, slotEditor, logList, retention, actions, confirmBox, recordStatus);
  root.append(section, dialog);

  function message(text, announce = false) {
    status.textContent = text; recordStatus.textContent = text;
    if (announce && typeof notify === 'function') notify(text);
  }
  function save() {
    try { win.localStorage.setItem(RELIEF_STORAGE_KEY, JSON.stringify(state)); return true; }
    catch { message('浏览器未能保存解压记录；当前页面仍保留，关闭前可导出 JSON。'); return false; }
  }
  function later(fn, delay) {
    const timer = win.setTimeout(() => { timers.delete(timer); if (!disposed) fn(); }, delay); timers.add(timer);
  }
  const reducedMotion = win.matchMedia?.('(prefers-reduced-motion: reduce)');
  const motionAllowed = () => state.settings.motion !== 'off' && !reducedMotion?.matches;
  function renderCompanion() {
    section.dataset.companion = hit.dataset.companion = voice.companion;
    stage.dataset.calm = String(calm);
    const src = voice.companion === 'lamb' ? './assets/relief-lamb.png'
      : calm ? './assets/relief-horse-calm.png' : './assets/relief-woodfish.png';
    if (illustration.getAttribute('src') !== src) illustration.setAttribute('src', src);
    illustration.hidden = voice.companion === 'none';
  }
  function releaseCopy() {
    return ({ confident: '这波到此为止，辛苦我了。', lamb: '今天也照顾到自己啦。',
      spicy: '这波到此为止，辛苦我了。', dry: '班味散一点，自己松口气。',
      quiet: '慢慢来，给自己留一点空间。', none: '画面已清空，敲击记录已保留。' })[voice.tone];
  }
  function setPersonality(value = {}) {
    voice = {
      tone: ['spicy', 'dry', 'quiet', 'none', 'confident', 'lamb'].includes(value.tone) ? value.tone : 'spicy',
      companion: ['horse', 'lamb', 'none'].includes(value.companion) ? value.companion : 'horse',
    };
    headingNote.textContent = ({ confident: '功劳给自己，情绪还给自己。', lamb: '今天的小羊，也值得被温柔照顾。',
      spicy: '工资慢慢赚，怨气先敲散。', dry: '敲掉一点班味，给自己松口气。',
      quiet: '想歇一下的时候，轻轻敲一下。', none: '点击播放解压效果，记录仅存本机。' })[voice.tone];
    renderCompanion();
    if (calm) releaseFeedback.textContent = releaseCopy();
  }
  function renderAtmosphere() {
    const sample = sampleAtmosphere(atmosphere, win.performance.now());
    stage.dataset.cloudLevel = String(sample.level);
    clouds.style.opacity = String(motionAllowed() ? sample.opacity : sample.level > 0 ? 1 : 0);
    return sample.level;
  }
  function animateAtmosphere() {
    if (atmosphereTimer !== null || disposed) return;
    const tick = () => {
      atmosphereTimer = null;
      if (!disposed && renderAtmosphere()) atmosphereTimer = win.setTimeout(tick, 100);
    };
    tick();
  }
  function stopAtmosphereTimer() {
    if (atmosphereTimer !== null) win.clearTimeout(atmosphereTimer);
    atmosphereTimer = null;
  }
  function removeMovingParticles() {
    stage.querySelectorAll('.relief-particle').forEach(node => node.remove());
    stage.classList.remove('relief-clearing');
  }
  function renderMain() {
    const today = reliefDateKey(Date.now());
    const count = state.events.filter(timestamp => reliefDateKey(timestamp) === today).length;
    countButton.textContent = `今天敲了 ${count.toLocaleString('zh-CN')} 下 · 查看记录`;
    skin.value = state.settings.skin; motion.value = state.settings.motion; sound.checked = state.settings.sound;
    hit.dataset.skin = state.settings.skin; objectLabel.textContent = state.settings.skin === 'keycap' ? '↵' : '敲';
    section.dataset.motion = reducedMotion?.matches ? 'off' : state.settings.motion;
    if (!motionAllowed()) removeMovingParticles();
    motionNote.textContent = reducedMotion?.matches ? '已跟随系统减少动态效果，保留静态云团与点击记录。' : '声音默认关闭。云团只是氛围效果，不代表真实压力程度。';
    renderCompanion();
  }
  function playSound() {
    if (!state.settings.sound) return;
    try {
      const Audio = win.AudioContext || win.webkitAudioContext;
      if (!Audio) throw new Error('no audio');
      audioContext ||= new Audio();
      if (audioContext.state === 'suspended') audioContext.resume().catch(() => {
        if (!soundFailureShown) { soundFailureShown = true; message('当前浏览器暂时无法播放点击音，解压记录不受影响。'); }
      });
      const osc = audioContext.createOscillator(), gain = audioContext.createGain(), now = audioContext.currentTime;
      osc.type = 'sine'; osc.frequency.setValueAtTime(state.settings.skin === 'woodfish' ? 380 : 620, now);
      osc.frequency.exponentialRampToValueAtTime(120, now + .055);
      gain.gain.setValueAtTime(.0001, now); gain.gain.exponentialRampToValueAtTime(.045, now + .005);
      gain.gain.exponentialRampToValueAtTime(.0001, now + .07);
      osc.connect(gain); gain.connect(audioContext.destination); osc.start(now); osc.stop(now + .08);
      osc.onended = () => { osc.disconnect(); gain.disconnect(); };
    } catch {
      if (!soundFailureShown) { soundFailureShown = true; message('当前浏览器暂时无法播放点击音，解压记录不受影响。'); }
    }
  }
  function floatOne() {
    if (state.settings.motion === 'off' || reducedMotion?.matches) return;
    // Keep rapid clicks from creating unbounded animated DOM nodes.
    const particles = stage.querySelectorAll('.relief-particle');
    if (particles.length >= 16) particles[0].remove();
    const particle = make('span', `relief-particle drift-${Math.floor(Math.random() * 5)}`, '+1 RMB');
    particle.dataset.motion = state.settings.motion; particle.setAttribute('aria-hidden', 'true'); stage.append(particle);
    later(() => particle.remove(), 1100);
  }
  hit.addEventListener('click', () => {
    // Native button click covers mouse, touch and keyboard activation exactly once.
    calm = false; clearGeneration++; releaseFeedback.textContent = ''; stage.classList.remove('relief-clearing');
    atmosphere = tapAtmosphere(atmosphere, win.performance.now());
    const now = Date.now(); state = addReliefEvent(state, now, now); save(); renderMain(); floatOne(); playSound();
    renderAtmosphere(); animateAtmosphere();
  });
  release.onclick = () => {
    // Only transient visual state is reset: no storage write and no history mutation.
    const hadClouds = sampleAtmosphere(atmosphere, win.performance.now()).level > 0;
    atmosphere = clearAtmosphere(); stopAtmosphereTimer(); removeMovingParticles(); renderAtmosphere();
    calm = true; renderCompanion(); releaseFeedback.textContent = releaseCopy();
    const generation = ++clearGeneration;
    if (hadClouds && motionAllowed()) {
      stage.classList.add('relief-clearing');
      later(() => { if (generation === clearGeneration) stage.classList.remove('relief-clearing'); }, 1100);
    }
  };
  function changeSettings() {
    state.settings = { skin: skin.value, sound: sound.checked, motion: motion.value };
    state = normalizeReliefState(state); save(); renderMain();
    if (!motionAllowed()) removeMovingParticles();
  }
  skin.onchange = motion.onchange = sound.onchange = changeSettings;
  reducedMotion?.addEventListener?.('change', renderMain);

  function rangeDates() {
    const today = reliefDateKey(Date.now());
    return rangeMode === 'week' ? { fromDate: shiftReliefDate(today, -6), toDate: today }
      : { fromDate: rangeMode === 'date' ? chosenDate : today, toDate: rangeMode === 'date' ? chosenDate : today };
  }
  function formatSlot(slot) { return `${slot.date.slice(5).replace('-', '月')}日 ${slot.label}`; }
  function renderSlot(group) {
    slotEditor.replaceChildren(); logList.replaceChildren();
    if (!group) return;
    const annotation = state.annotations[group.key] || { mood: '', note: '' };
    const caption = make('h3', '', `${formatSlot(group)} · ${group.count} 次`);
    const mood = select([['', '不标记'], ...Object.entries(MOODS)], '这个时段的感受'); mood.value = annotation.mood;
    const note = make('textarea'); note.rows = 2; note.maxLength = 120; note.placeholder = '可选：刚开完会，或者只是随手玩玩'; note.value = annotation.note;
    const saveNote = button('保存这段感受', 'primary-button');
    slotEditor.append(caption, labelled('我自己标记的感受', mood), labelled('备注（可选，最多 120 字）', note), saveNote);
    saveNote.onclick = () => {
      state.annotations[group.key] = { mood: mood.value, note: note.value };
      state = normalizeReliefState(state); const persisted = save(); renderRecords();
      if (persisted) recordStatus.textContent = '这段感受已保存在当前浏览器。';
    };
    const events = state.events.filter(timestamp => slotFor(timestamp).key === group.key).reverse();
    const details = make('details'); details.append(make('summary', '', `展开点击时间（${events.length} 次${events.length > 100 ? '，显示最近 100 条' : ''}）`));
    const list = make('ol');
    for (const timestamp of events.slice(0, 100)) {
      const d = new Date(timestamp + CHINA_OFFSET), time = d.toISOString().slice(11, 23);
      list.append(make('li', '', `${time} · 敲一下`));
    }
    details.append(list); logList.append(details);
  }
  function renderRecords() {
    const now = Date.now(), today = reliefDateKey(now);
    state = normalizeReliefState(state, now);
    range.value = rangeMode; dateLabel.hidden = rangeMode !== 'date'; dateInput.value = chosenDate;
    dateInput.min = shiftReliefDate(today, -(RELIEF_RETENTION_DAYS - 1)); dateInput.max = today;
    const dates = rangeDates(), groups = groupReliefEvents(state.events, dates);
    const count = groups.reduce((total, group) => total + group.count, 0);
    summary.textContent = `${dates.fromDate}${dates.toDate !== dates.fromDate ? ` 至 ${dates.toDate}` : ''} · 共敲了 ${count.toLocaleString('zh-CN')} 下`;
    const top = [...groups].sort((a, b) => b.count - a.count || a.key.localeCompare(b.key))[0];
    const tied = top ? groups.filter(group => group.count === top.count).length : 0;
    concentration.textContent = top ? `点击集中时段：${formatSlot(top)}，${top.count} 次${tied > 1 ? `（另有 ${tied - 1} 个时段并列）` : ''}。点击次数不等于压力程度。` : '还没有解压记录。想敲就敲，不用完成任何次数。';
    if (!groups.some(group => group.key === selectedSlot)) selectedSlot = top?.key || '';
    bars.replaceChildren();
    for (const group of groups) {
      const row = button('', 'relief-bar-row'); row.setAttribute('aria-pressed', String(group.key === selectedSlot));
      row.dataset.selected = String(group.key === selectedSlot);
      const labelledTime = dates.fromDate !== dates.toDate ? formatSlot(group) : group.label;
      row.setAttribute('aria-label', `${labelledTime}，${group.count} 次，查看和标记感受`);
      const track = make('meter', 'relief-bar-track'); track.min = 0; track.max = Math.max(1, top?.count || 1); track.value = group.count;
      track.setAttribute('aria-hidden', 'true');
      const mark = state.annotations[group.key]?.mood;
      row.append(make('span', 'relief-bar-label', labelledTime), track, make('span', 'relief-bar-count', `${group.count}${mark ? ` · ${MOODS[mark]}` : ''}`));
      row.onclick = () => { selectedSlot = group.key; renderRecords(); };
      bars.append(row);
    }
    renderSlot(groups.find(group => group.key === selectedSlot));
    deleteDay.textContent = rangeMode === 'date' ? `删除 ${chosenDate.slice(5)} 记录` : '删除当天记录';
    exportButton.disabled = deleteAll.disabled = state.events.length === 0;
    const deletionDate = rangeMode === 'date' ? chosenDate : today;
    deleteDay.disabled = !state.events.some(timestamp => reliefDateKey(timestamp) === deletionDate);
  }
  function openRecords() {
    if (disposed) return;
    state = normalizeReliefState(state); save(); renderMain(); renderRecords();
    pendingDelete = null; confirmBox.hidden = true;
    if (!dialog.open) dialog.showModal();
  }
  countButton.onclick = records.onclick = openRecords;
  close.onclick = () => dialog.close();
  dialog.addEventListener('click', event => {
    if (event.target !== dialog) return;
    const rect = dialog.getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
  });
  range.onchange = () => { rangeMode = range.value; selectedSlot = ''; confirmBox.hidden = true; pendingDelete = null; renderRecords(); };
  dateInput.onchange = () => {
    try {
      dateTimestamp(dateInput.value);
      if (dateInput.value < dateInput.min || dateInput.value > dateInput.max) throw new RangeError();
      chosenDate = dateInput.value; selectedSlot = ''; confirmBox.hidden = true; pendingDelete = null; renderRecords();
    } catch { recordStatus.textContent = '请选择最近 90 天内的有效日期。'; dateInput.value = chosenDate; }
  };
  exportButton.onclick = () => {
    state = normalizeReliefState(state);
    const output = { ...state, exportedAt: new Date().toISOString(), displayTimeZone: 'Asia/Shanghai', description: '点击解压记录，不是工资或压力诊断。' };
    const blob = new win.Blob([JSON.stringify(output, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = win.URL.createObjectURL(blob), anchor = make('a'); downloadUrls.add(url);
    anchor.href = url; anchor.download = `薪动-解压记录-${reliefDateKey(Date.now())}.json`; anchor.hidden = true; root.append(anchor); anchor.click(); anchor.remove();
    later(() => { win.URL.revokeObjectURL(url); downloadUrls.delete(url); }, 1500);
    recordStatus.textContent = '已生成本地 JSON 下载，仅包含解压记录、感受标记和解压设置。';
  };
  function askDelete(scope) {
    pendingDelete = { scope, date: rangeMode === 'date' ? chosenDate : reliefDateKey(Date.now()) };
    confirmText.textContent = scope === 'all' ? '确定删除本浏览器的全部解压记录及感受标记？删除后无法恢复，工资资料不受影响。'
      : `确定删除 ${pendingDelete.date} 的解压记录及感受标记？删除后无法恢复。`;
    confirmBox.hidden = false; cancelDelete.focus();
  }
  deleteDay.onclick = () => askDelete('day'); deleteAll.onclick = () => askDelete('all');
  cancelDelete.onclick = () => { pendingDelete = null; confirmBox.hidden = true; };
  confirmDelete.onclick = () => {
    if (!pendingDelete) return;
    const previous = state;
    state = normalizeReliefState({ ...state, events: pendingDelete.scope === 'all' ? [] : state.events.filter(timestamp => reliefDateKey(timestamp) !== pendingDelete.date) });
    if (!save()) { state = previous; recordStatus.textContent = '删除未完成：浏览器存储无法写入。请重试，或在浏览器设置中清理本站数据。'; return; }
    pendingDelete = null; confirmBox.hidden = true; selectedSlot = ''; renderMain(); renderRecords();
    recordStatus.textContent = '所选解压记录及对应标记已删除。';
  };
  let renderedDate = reliefDateKey(Date.now());
  function refreshDay() {
    const today = reliefDateKey(Date.now());
    if (today === renderedDate) return;
    renderedDate = today; state = normalizeReliefState(state); save(); renderMain();
    // Do not rebuild an open editor and erase a note that the user is typing.
    if (dialog.open) recordStatus.textContent = '新的一天开始了。重新选择查看范围即可刷新记录，正在填写的备注保留。';
  }
  const refreshTimer = win.setInterval(refreshDay, 30_000);
  setPersonality(personality); save(); renderMain(); renderAtmosphere();
  return {
    openRecords,
    setPersonality,
    destroy() {
      disposed = true; stopAtmosphereTimer(); timers.forEach(timer => win.clearTimeout(timer)); timers.clear(); win.clearInterval(refreshTimer);
      downloadUrls.forEach(url => win.URL.revokeObjectURL(url)); downloadUrls.clear();
      reducedMotion?.removeEventListener?.('change', renderMain); audioContext?.close().catch(() => {});
      dialog.close(); section.remove(); dialog.remove();
    },
  };
}
