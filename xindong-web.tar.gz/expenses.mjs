import { calendarDate, getCalendarDay, getWorkdaysInMonth } from './calendar.mjs';

/**
 * Monthly expenses split into integer cents across actual calendar workdays.
 * Early workdays receive the remainder cents. Changing the salary's manual
 * divisor never changes this split. Pass the engine's shiftDate for night work.
 * Off days preview the next (or last) share of this month, without earning it.
 */
export function allocateExpenses(goals, { date = new Date(), profile = {}, earned = 0 } = {}) {
  if (!Array.isArray(goals) || goals.length > 100) throw new RangeError('开销清单无效');
  if (typeof earned !== 'number' || !Number.isFinite(earned) || earned < 0) throw new RangeError('已赚金额无效');
  const day = calendarDate(date);
  const calendar = getCalendarDay(day, profile);
  const workdays = getWorkdaysInMonth(day.getFullYear(), day.getMonth(), profile);
  let ordinal = workdays.findIndex(d => d.getDate() >= day.getDate());
  if (ordinal < 0) ordinal = workdays.length - 1;
  let thresholdCents = 0;
  return goals.map(goal => {
    if (!goal || typeof goal.name !== 'string' || !goal.name.trim() || goal.name.length > 60
        || typeof goal.price !== 'number' || !Number.isFinite(goal.price) || goal.price <= 0 || goal.price > 1_000_000_000
        || (goal.period !== undefined && !['daily', 'monthly'].includes(goal.period))) throw new RangeError('开销名称、金额或周期无效');
    const period = goal.period ?? 'daily';
    const priceCents = Math.round((goal.price + Number.EPSILON) * 100);
    if (priceCents <= 0) throw new RangeError('开销金额至少为 0.01 元');
    const dailyCents = period === 'daily' ? priceCents : workdays.length === 0 ? 0
      : Math.floor(priceCents / workdays.length) + (ordinal < priceCents % workdays.length ? 1 : 0);
    thresholdCents += dailyCents;
    const threshold = thresholdCents / 100;
    return {
      ...goal, price: priceCents / 100, period, dailyPrice: dailyCents / 100, threshold,
      done: calendar.isWorkday && dailyCents > 0 && earned + 1e-8 >= threshold,
      allocationActive: calendar.isWorkday,
      notDue: dailyCents === 0,
    };
  });
}
