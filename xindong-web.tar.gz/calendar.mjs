/** Mainland China 2026 public holidays, verified against the State Council notice. */
export const CHINA_CALENDAR = Object.freeze({
  years: Object.freeze([2026]),
  source: 'https://www.gov.cn/zhengce/content/202511/content_7047090.htm',
  notice: '国务院办公厅关于2026年部分节假日安排的通知（国办发明电〔2025〕7号）',
  checkedAt: '2026-11-03',
});

const holidays = new Map();
const makeup = new Map();
for (const [month, first, last, name] of [
  [1, 1, 3, '元旦'], [2, 15, 23, '春节'], [4, 4, 6, '清明节'],
  [5, 1, 5, '劳动节'], [6, 19, 21, '端午节'], [9, 25, 27, '中秋节'], [10, 1, 7, '国庆节'],
]) {
  for (let day = first; day <= last; day++)
    holidays.set(`2026-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`, `${name}假期`);
}
for (const [date, name] of [
  ['2026-01-04', '元旦'], ['2026-02-14', '春节'], ['2026-02-28', '春节'],
  ['2026-05-09', '劳动节'], ['2026-09-20', '国庆节'], ['2026-10-10', '国庆节'],
]) makeup.set(date, `${name}调休上班`);

export const isKnownCalendarYear = (year) => CHINA_CALENDAR.years.includes(Number(year));

/** Parse date-only strings as local dates, avoiding UTC's previous-day shift. */
export function calendarDate(value) {
  if (value instanceof Date && Number.isFinite(value.getTime())) return new Date(value.getTime());
  const match = typeof value === 'string' && /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (match) {
    const [, y, m, d] = match.map(Number);
    const result = new Date(y, m - 1, d, 12);
    if (result.getFullYear() === y && result.getMonth() === m - 1 && result.getDate() === d) return result;
  }
  throw new RangeError('请提供有效日期，格式为 YYYY-MM-DD');
}

export function localDateKey(value) {
  const date = calendarDate(value);
  return `${String(date.getFullYear()).padStart(4, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

/** Optional date overrides contain only real, local dates and boolean values. */
export function validateDateOverrides(overrides) {
  if (overrides === undefined) return { valid: true };
  if (!overrides || typeof overrides !== 'object' || Array.isArray(overrides)
      || ![null, Object.prototype].includes(Object.getPrototypeOf(overrides)))
    return { valid: false, error: '每日作息设置必须是日期与工作状态组成的对象' };
  const entries = Object.entries(overrides);
  if (entries.length > 3660) return { valid: false, error: '每日作息设置最多保存 3660 个日期' };
  for (const [date, isWorkday] of entries) {
    if (typeof isWorkday !== 'boolean') return { valid: false, error: '每日作息状态只能是工作或休息' };
    try { calendarDate(date); } catch { return { valid: false, error: `每日作息包含无效日期：${date}` }; }
  }
  return { valid: true };
}

function checkedOverrides(profile) {
  const overrides = profile?.dateOverrides;
  const validation = validateDateOverrides(overrides);
  if (!validation.valid) throw new RangeError(validation.error);
  return overrides ?? {};
}

function getMode(profile) {
  const mode = profile?.calendarMode ?? 'custom';
  if (mode !== 'custom' && mode !== 'china') throw new RangeError('工作日历模式无效');
  return mode;
}

function customWeekdays(profile) {
  const days = profile?.weekdays ?? [1, 2, 3, 4, 5];
  if (!Array.isArray(days) || days.length === 0 || days.some(day => !Number.isInteger(day) || day < 0 || day > 6)
      || new Set(days).size !== days.length) throw new RangeError('请至少选择一个有效工作日，且不能重复');
  return days;
}

function yearKnown(year, mode, overrides) {
  if (mode === 'custom' || isKnownCalendarYear(year)) return true;
  const prefix = `${String(year).padStart(4, '0')}-`;
  const daysInYear = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0) ? 366 : 365;
  return Object.keys(overrides).filter(key => key.startsWith(prefix)).length === daysInYear;
}

/** A single explicit date must not imply that an unknown annual calendar is known. */
export function isCalendarYearKnown(year, profile = {}) {
  if (!Number.isInteger(year) || year < 100 || year > 9999) throw new RangeError('年份无效');
  return yearKnown(year, getMode(profile), checkedOverrides(profile));
}

function resolveDay(date, mode, weekdays, overrides, calendarKnown) {
  const key = localDateKey(date);
  if (Object.hasOwn(overrides, key)) {
    const isWorkday = overrides[key];
    return { isWorkday, name: isWorkday ? '自选工作日' : '自选休息日', known: true, override: true, calendarKnown };
  }
  if (mode === 'custom') {
    const isWorkday = weekdays.includes(date.getDay());
    return { isWorkday, name: isWorkday ? '自定义工作日' : '自定义休息日', known: true, override: false, calendarKnown };
  }
  const known = isKnownCalendarYear(date.getFullYear());
  if (known && makeup.has(key)) return { isWorkday: true, name: makeup.get(key), known, override: false, calendarKnown };
  if (known && holidays.has(key)) return { isWorkday: false, name: holidays.get(key), known, override: false, calendarKnown };
  const isWorkday = date.getDay() >= 1 && date.getDay() <= 5;
  return { isWorkday, name: `${isWorkday ? '工作日' : '周末'}${known ? '' : '（节假日未知，暂估）'}`, known, override: false, calendarKnown };
}

export function getCalendarDay(value, profile = {}) {
  const date = calendarDate(value);
  const mode = getMode(profile);
  const weekdays = mode === 'custom' ? customWeekdays(profile) : [];
  const overrides = checkedOverrides(profile);
  return resolveDay(date, mode, weekdays, overrides, yearKnown(date.getFullYear(), mode, overrides));
}

export function getWorkdaysInMonth(year, monthIndex, profile = {}) {
  if (!Number.isInteger(year) || year < 100 || year > 9999 || !Number.isInteger(monthIndex) || monthIndex < 0 || monthIndex > 11)
    throw new RangeError('年份或月份无效');
  const mode = getMode(profile);
  const weekdays = mode === 'custom' ? customWeekdays(profile) : [];
  const overrides = checkedOverrides(profile);
  const known = yearKnown(year, mode, overrides);
  const dates = [];
  const last = new Date(year, monthIndex + 1, 0).getDate();
  for (let day = 1; day <= last; day++) {
    const date = new Date(year, monthIndex, day, 12);
    if (resolveDay(date, mode, weekdays, overrides, known).isWorkday) dates.push(date);
  }
  return dates;
}

export function countWorkdays(year, monthIndex, profile = {}) {
  return getWorkdaysInMonth(year, monthIndex, profile).length;
}
