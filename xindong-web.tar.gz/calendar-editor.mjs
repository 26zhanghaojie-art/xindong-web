import {getCalendarDay,countWorkdays,localDateKey,isCalendarYearKnown} from './calendar.mjs';

export function createCalendarEditor({root,getProfile,getOverrides,onChange,getNet}){
  let view=new Date();
  const make=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e;};
  function render(){
    const profile={...getProfile(),dateOverrides:getOverrides()},year=view.getFullYear(),month=view.getMonth();
    root.replaceChildren();
    if(profile.calendarMode==='custom'&&!profile.weekdays?.length){root.append(make('p','month-help','请先选择至少一个默认工作日，再逐日调整休息安排。整月休息可使用“本月全休”。'));return;}
    const days=new Date(year,month+1,0).getDate(),workdays=countWorkdays(year,month,profile);
    const toolbar=make('div','month-toolbar'),prev=make('button','','‹'),next=make('button','','›'),monthInput=document.createElement('input');
    monthInput.type='month';monthInput.min='2020-01';monthInput.max='2099-12';monthInput.value=`${year}-${String(month+1).padStart(2,'0')}`;monthInput.setAttribute('aria-label','选择月份');
    prev.type=next.type='button';prev.setAttribute('aria-label','上个月');next.setAttribute('aria-label','下个月');
    prev.onclick=()=>{if(year===2020&&month===0)return;view=new Date(year,month-1,1);render();};next.onclick=()=>{if(year===2099&&month===11)return;view=new Date(year,month+1,1);render();};
    monthInput.onchange=()=>{const m=/^(\d{4})-(\d{2})$/.exec(monthInput.value);if(m&&Number(m[1])>=2020&&Number(m[1])<=2099){view=new Date(Number(m[1]),Number(m[2])-1,1);render();}};
    toolbar.append(prev,monthInput,next);root.append(toolbar);
    const summary=make('div','month-summary',`${month+1} 月 ${days} 天 · 工作 ${workdays} 天 · 休息 ${days-workdays} 天`);root.append(summary);
    if(profile.calendarMode==='china'&&!isCalendarYearKnown(year,profile))root.append(make('p','month-help','本年度官方节假日尚未加载，暂按周一至周五安排，可逐日修改。'));
    const net=getNet();if(Number.isFinite(net)&&net>0)root.append(make('div','month-net',workdays?`按本月日历折算日薪 ¥ ${(net/workdays).toFixed(2)}`:'整月休息：日薪及今日计薪均为 0，不进行除零计算。'));
    const grid=make('div','month-grid');grid.setAttribute('role','group');grid.setAttribute('aria-label',`${year}年${month+1}月工作休息日历`);
    for(const label of ['一','二','三','四','五','六','日'])grid.append(make('span','weekday-heading',label));
    const offset=(new Date(year,month,1).getDay()+6)%7;for(let i=0;i<offset;i++)grid.append(make('span','calendar-blank'));
    for(let day=1;day<=days;day++){
      const date=new Date(year,month,day,12),key=localDateKey(date),info=getCalendarDay(date,profile),button=make('button',`calendar-day ${info.isWorkday?'is-work':'is-rest'}${info.override?' is-override':''}`);
      button.type='button';button.setAttribute('aria-pressed',String(!info.isWorkday));button.setAttribute('aria-label',`${year}年${month+1}月${day}日 ${info.isWorkday?'工作':'休息'}${info.override?' 自选':''}，点击切换`);
      button.append(make('b','',String(day)),make('small','',info.isWorkday?'班':'休'));button.title=info.name;
      button.onclick=()=>{onChange({...getOverrides(),[key]:!info.isWorkday});render();};grid.append(button);
    }root.append(grid);
    const actions=make('div','calendar-actions');
    for(const [label,value]of [['本月全班',true],['本月全休',false],['恢复本月默认',null]]){const b=make('button','text-button',label);b.type='button';b.onclick=()=>{const overrides={...getOverrides()};for(let d=1;d<=days;d++){const key=localDateKey(new Date(year,month,d,12));if(value===null)delete overrides[key];else overrides[key]=value;}onChange(overrides);render();};actions.append(b);}root.append(actions);
    root.append(make('p','month-help','点击日期切换工作／休息，描边表示手动调整。选择会在“保存作息”后生效；其他月份的安排保留。'));
  }
  return {render,resetMonth(){view=new Date();render();}};
}
