/**
 * Salary Clock's shared, dependency-free calculation engine.
 * The estimate models twelve equal months of mainland-China resident salary.
 * It is an annual average, not an employer's cumulative monthly withholding.
 */

import { getCalendarDay, countWorkdays, validateDateOverrides } from './calendar.mjs';
import { calculateContributions } from './contributions.mjs';

const TAX_BRACKETS = [
  [36_000, 0.03, 0],
  [144_000, 0.10, 2_520],
  [300_000, 0.20, 16_920],
  [420_000, 0.25, 31_920],
  [660_000, 0.30, 52_920],
  [960_000, 0.35, 85_920],
  [Infinity, 0.45, 181_920],
];
const TIME = /^([01]\d|2[0-3]):([0-5]\d)$/;
const money = (value) => Math.round((value + Number.EPSILON) * 100) / 100;
const numeric = (value) =>
  (typeof value === 'number' || (typeof value === 'string' && value.trim() !== ''))
  && Number.isFinite(Number(value));

function invalid(errors) {
  const error = new RangeError(Object.values(errors).join('；'));
  error.errors = errors;
  return error;
}

function salaryErrors(input = {}) {
  const { gross, special = 0 } = input;
  let social = input.social ?? 0;
  const errors = {};
  if (input.salaryMode === 'contributions') {
    // Manual totals from previously selected modes must never affect this mode.
    social = 0;
    try { social = calculateContributions(input).social; }
    catch (error) { Object.assign(errors, error.errors ?? { contributions: error.message }); }
  }
  if (!numeric(gross) || Number(gross) <= 0 || Number(gross) > 1_000_000_000)
    errors.gross = '请填写大于 0 且不超过 10 亿元的税前月薪';
  if (!numeric(social) || Number(social) < 0 || Number(social) > Number(gross))
    errors.social = '个人五险一金应在 0 和税前月薪之间';
  if (!numeric(special) || Number(special) < 0 || Number(special) > 1_000_000_000)
    errors.special = '专项附加扣除应为非负金额';
  return errors;
}

/** Personal contributions are cash deductions; special deductions reduce tax only. */
export function estimateSalary(input = {}) {
  const errors = salaryErrors(input);
  if (Object.keys(errors).length) throw invalid(errors);
  const gross = Number(input.gross);
  const contributions = input.salaryMode === 'contributions' ? calculateContributions(input) : null;
  const social = contributions ? contributions.social : Number(input.social ?? 0);
  const special = Number(input.special ?? 0);
  const annualTaxable = Math.max(0, money((gross - social - special) * 12 - 60_000));
  const [, rate, quickDeduction] = TAX_BRACKETS.find(([ceiling]) => annualTaxable <= ceiling);
  const annualTax = money(Math.max(0, annualTaxable * rate - quickDeduction));
  return {
    gross, social, special, annualTaxable, annualTax,
    ...(contributions ? { contributions } : {}),
    monthlyTax: money(annualTax / 12),
    net: money(Math.max(0, gross - social - annualTax / 12)),
    estimated: true,
  };
}

function minutes(value) {
  const match = typeof value === 'string' && value.match(TIME);
  return match ? Number(match[1]) * 60 + Number(match[2]) : NaN;
}

function schedule(profile) {
  const start = minutes(profile.start);
  let end = minutes(profile.end);
  if (end < start) end += 1440;
  return { start, end };
}

/** Numeric strings from form inputs are accepted. Weekday uses JS's 0=Sunday. */
export function validateProfile(profile) {
  if (!profile || typeof profile !== 'object')
    return { valid: false, errors: { profile: '请先填写工资和工作时间' } };
  const errors = {};
  if (typeof profile.nickname !== 'string' || !profile.nickname.trim() || profile.nickname.trim().length > 40)
    errors.nickname = '昵称需要填写 1 到 40 个字符';
  if (!['estimate', 'contributions', 'manual'].includes(profile.salaryMode))
    errors.salaryMode = '请选择填写扣款金额、按基数比例估算或填写税后月薪';
  if (['estimate', 'contributions'].includes(profile.salaryMode)) Object.assign(errors, salaryErrors(profile));
  if (profile.salaryMode === 'manual'
      && (!numeric(profile.net) || Number(profile.net) <= 0 || Number(profile.net) > 1_000_000_000))
    errors.net = '请填写大于 0 且不超过 10 亿元的税后月薪';
  if (profile.calendarMode !== undefined && !['china', 'custom'].includes(profile.calendarMode))
    errors.calendarMode = '请选择中国大陆日历或自定义工作星期';
  if (profile.workdaysMode !== undefined && !['calendar', 'manual'].includes(profile.workdaysMode))
    errors.workdaysMode = '请选择日历工作日或手动填写工作日';
  const overrides = validateDateOverrides(profile.dateOverrides);
  if (!overrides.valid) errors.dateOverrides = overrides.error;
  if (profile.workdaysMode !== 'calendar'
      && (!numeric(profile.workdays) || Number(profile.workdays) < 1 || Number(profile.workdays) > 31))
    errors.workdays = '月工作日应在 1 到 31 天之间';
  if (!Number.isFinite(minutes(profile.start))) errors.start = '请填写有效的上班时间';
  if (!Number.isFinite(minutes(profile.end))) errors.end = '请填写有效的下班时间';
  if (!errors.start && !errors.end && profile.start === profile.end)
    errors.end = '上班时间和下班时间不能相同';
  if (profile.calendarMode !== 'china' && (!Array.isArray(profile.weekdays) || !profile.weekdays.length
      || profile.weekdays.some((day) => !Number.isInteger(day) || day < 0 || day > 6)
      || new Set(profile.weekdays).size !== profile.weekdays.length))
    errors.weekdays = '请至少选择一个工作日，且不能重复';
  // Saved lunch settings from earlier versions are intentionally ignored.
  // Every minute between clock-in and clock-out now counts toward daily pay.
  return { valid: Object.keys(errors).length === 0, errors };
}

function localDateKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function atMinute(date, minute) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, minute, 0, 0);
}

/**
 * Calculate from absolute timestamps on every paint, so sleep, throttled tabs,
 * or reopening cannot accumulate drift. The device's local timezone is used.
 * An active overnight shift belongs to the date it started (also at shift end).
 * Following that end, the next shift is shown as 'before' or 'off'.
 * Lunch is paid continuously, regardless of any legacy lunch profile fields.
 */
export function getDayProgress(profile, date = new Date()) {
  const validation = validateProfile(profile);
  if (!validation.valid) throw invalid(validation.errors);
  if (!(date instanceof Date) || !Number.isFinite(date.getTime()))
    throw invalid({ date: '当前时间无效' });
  const s = schedule(profile);
  let shiftDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  if (s.end >= 1440) {
    const previous = new Date(date.getFullYear(), date.getMonth(), date.getDate() - 1);
    if (date.getTime() <= atMinute(previous, s.end).getTime()
        && getCalendarDay(previous, profile).isWorkday) shiftDate = previous;
  }
  const start = atMinute(shiftDate, s.start).getTime();
  const end = atMinute(shiftDate, s.end).getTime();
  const totalSeconds = (end - start) / 1000;
  if (totalSeconds <= 0) throw invalid({ end: '此日期的有效工作时间必须大于 0' });
  const net = profile.salaryMode === 'manual' ? Number(profile.net) : estimateSalary(profile).net;
  const calendarWorkdays = countWorkdays(shiftDate.getFullYear(), shiftDate.getMonth(), profile);
  const emptyMonth = calendarWorkdays === 0;
  const workdays = emptyMonth ? 0 : profile.workdaysMode === 'calendar' ? calendarWorkdays : Number(profile.workdays);
  const daily = emptyMonth ? 0 : net / workdays;
  const perSecond = daily / totalSeconds;
  const now = date.getTime();
  const calendar = getCalendarDay(shiftDate, profile);
  const isWorkday = !emptyMonth && calendar.isWorkday;
  const elapsed = Math.max(0, Math.min(now, end) - start);
  const workedSeconds = isWorkday
    ? Math.max(0, Math.min(totalSeconds, elapsed / 1000)) : 0;
  const progress = Math.min(1, workedSeconds / totalSeconds);
  const status = !isWorkday ? 'off' : now < start ? 'before' : now >= end ? 'finished' : 'working';
  return {
    earned: Math.min(daily, daily * progress), daily, perSecond,
    workedSeconds, totalSeconds, remainingSeconds: totalSeconds - workedSeconds,
    progress, status, shiftDate: localDateKey(shiftDate), net, workdays, calendarWorkdays, emptyMonth,
    calendarKnown: calendar.calendarKnown, calendarDayKnown: calendar.known, calendarName: calendar.name,
    calendarOverride: calendar.override,
    shiftStart: new Date(start).toISOString(), shiftEnd: new Date(end).toISOString(),
  };
}
