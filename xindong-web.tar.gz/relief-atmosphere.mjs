/** Ephemeral desk-toy atmosphere. It has no access to salary or saved history. */
export const ATMOSPHERE_WINDOW_MS = 10_000;
export const ATMOSPHERE_FADE_START_MS = 3_000;
export const ATMOSPHERE_FADE_END_MS = 12_000;
export const ATMOSPHERE_MAX_TAPS = 64;

export function clearAtmosphere() {
  return { recent: [], lastTap: null, level: 0 };
}

export function tapAtmosphere(state, now) {
  if (!Number.isFinite(now) || now < 0) throw new RangeError('无效动效时间');
  const recent = [...state.recent.filter(time => time > now - ATMOSPHERE_WINDOW_MS && time <= now), now]
    .slice(-ATMOSPHERE_MAX_TAPS);
  return { recent, lastTap: now, level: recent.length >= 10 ? 3 : recent.length >= 4 ? 2 : 1 };
}

export function sampleAtmosphere(state, now) {
  if (state.lastTap === null || now < state.lastTap) return { level: 0, opacity: 0 };
  const idle = now - state.lastTap;
  const opacity = Math.max(0, Math.min(1, 1 - (idle - ATMOSPHERE_FADE_START_MS)
    / (ATMOSPHERE_FADE_END_MS - ATMOSPHERE_FADE_START_MS)));
  // Keep the last click's density while fading; expired clicks never enter the next burst.
  return { level: opacity > 0 ? state.level : 0, opacity };
}
