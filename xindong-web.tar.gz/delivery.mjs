import { estimateSalary, getDayProgress, validateProfile } from './engine.mjs';

/**
 * A public form endpoint is intentional; no mailbox password or SMTP key ships
 * with the app. Set formUrl to the actual hosted collection page before release.
 * Never call sendProfile automatically: the caller must obtain fresh consent.
 */
export const EMAIL_DELIVERY = Object.freeze({
  recipient: '895429442@qq.com',
  service: 'FormSubmit',
  endpoint: 'https://formsubmit.co/ajax/895429442@qq.com',
  formUrl: 'https://xindong-salary-20261103.hale-elk-0322.chatgpt.site/',
  privacyUrl: 'https://formsubmit.co/privacy.pdf',
  retainedDays: 30,
});

export class DeliveryError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'DeliveryError';
    this.code = code;
  }
}

const money = (n) => Number(n).toFixed(2);
const WEEKDAYS = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];

function checkedFormUrl(value) {
  let url;
  try { url = new URL(value); } catch { /* handled below */ }
  if (!url || url.protocol !== 'https:' || url.username || url.password || url.hash)
    throw new DeliveryError('not_configured', '邮件接收页尚未接通，请先由发布者配置真实的 HTTPS 表单地址。资料仍保存在本机。');
  return url.href;
}

/** Build only the disclosed fields; arbitrary profile keys cannot alter routing. */
export function buildEmailPayload(profile, {
  consent = false,
  formUrl = EMAIL_DELIVERY.formUrl,
  goals = [],
  includeGoals = false,
  now = new Date(),
} = {}) {
  if (consent !== true)
    throw new DeliveryError('consent_required', '请先阅读发送说明并勾选同意，再发送资料。');
  const validation = validateProfile(profile);
  if (!validation.valid)
    throw new DeliveryError('invalid_profile', Object.values(validation.errors).join('；'));
  const pageUrl = checkedFormUrl(formUrl);
  const day = getDayProgress(profile, now);
  const payload = {
    _subject: '【薪动】新的用户资料',
    _template: 'table',
    _url: pageUrl,
    _honey: '',
    '昵称': profile.nickname.trim(),
    '工资计算方式': profile.salaryMode === 'manual' ? '本人填写实际税后月薪' : profile.salaryMode === 'contributions' ? '缴费基数比例＋大陆个税年均估算（非实际当月发薪）' : '大陆个税年均估算（非实际当月发薪）',
  };
  if (profile.salaryMode !== 'manual') {
    const estimate = estimateSalary(profile);
    Object.assign(payload, {
      '税前月薪（元）': money(estimate.gross),
      '个人五险一金（月，元）': money(estimate.social),
      '专项附加扣除（月，元）': money(estimate.special),
      '估算年均月个税（元）': money(estimate.monthlyTax),
    });
  }
  Object.assign(payload, {
    '税后月薪（元）': money(day.net),
    '月工作日': String(day.workdays),
    '日薪折算方式': profile.workdaysMode === 'calendar' ? '当月日历工作日自动折算' : '手动填写工作日',
    '资料用途': '了解用户情况，改进产品',
    '税后日薪（元）': money(day.daily),
    '税后时薪（元）': money(day.perSecond * 3600),
    '上班时间': profile.start,
    '下班时间': profile.end,
    '工作日历': profile.calendarMode === 'china' ? `中国大陆法定节假日及调休＋自选日期（${day.calendarKnown ? '已加载本年日历' : '本年默认日历未加载，未指定日期暂估'}）` : '自定义工作日＋自选日期',
    '计薪规则': '上下班时段连续计薪（含午休）',
    '提交时间（UTC）': now.toISOString(),
    '填写人授权': '填写人主动勾选同意通过 FormSubmit 发送本次表单资料至发布者邮箱',
  });
  if (includeGoals === true) {
    if (!Array.isArray(goals) || goals.length > 50)
      throw new DeliveryError('invalid_goals', '日常开销最多支持 50 项。');
    let threshold = 0;
    payload['日常开销清单（已同意发送）'] = goals.map((goal, i) => {
      if (!goal || typeof goal.name !== 'string' || !goal.name.trim() || goal.name.length > 60
          || typeof goal.price === 'boolean' || goal.price === null || String(goal.price).trim() === ''
          || !Number.isFinite(Number(goal.price)) || Number(goal.price) <= 0 || Number(goal.price) > 1_000_000_000)
        throw new DeliveryError('invalid_goals', `第 ${i + 1} 项开销名称或金额无效。`);
      threshold += Number(goal.price);
      return `${i + 1}. ${goal.name.trim()}：¥${money(goal.price)}；累计覆盖门槛 ¥${money(threshold)}`;
    }).join('\n') || '未填写';
  }
  return payload;
}

/**
 * Returns accepted only for an explicit provider acknowledgement. This is NOT
 * an inbox-delivery receipt. A timeout is not retried automatically: the server
 * may have accepted it already. Tests inject fetchImpl and never send email.
 */
export async function sendProfile(profile, options = {}) {
  const payload = buildEmailPayload(profile, options);
  const fetchImpl = options.fetchImpl ?? globalThis.fetch;
  if (typeof fetchImpl !== 'function')
    throw new DeliveryError('unavailable', '此环境暂不支持发送，请使用桌面应用。');
  const controller = new AbortController();
  const timeoutMs = options.timeoutMs ?? 15_000;
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0 || timeoutMs > 60_000)
    throw new DeliveryError('invalid_timeout', '发送超时设置无效。');
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => {
      controller.abort();
      reject(new DeliveryError('timeout', '发送超时，无法确认服务是否已接收。请先检查收件箱，再决定是否重试。'));
    }, timeoutMs);
  });
  try {
    const request = (async () => {
      const response = await fetchImpl(EMAIL_DELIVERY.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(payload),
        signal: controller.signal,
        credentials: 'omit',
        redirect: 'error',
      });
      if (!response || !response.ok)
        throw new DeliveryError('service_error', '邮件服务暂时未能接受提交，请稍后重试。资料仍保存在本机。');
      let result;
      try { result = await response.json(); } catch {
        throw new DeliveryError('invalid_response', '邮件服务未返回有效确认，可能需要验证。请由发布者检查接收页，不能据此判断已经发送。');
      }
      const message = typeof result?.message === 'string' ? result.message : '';
      const activation = /(?:activat|confirm|verif).{0,100}(?:email|form)|(?:email|form).{0,100}(?:activat|confirm|verif)/i.test(message);
      if (activation)
        throw new DeliveryError('activation_required', '收件邮箱尚需激活。请发布者检查 QQ 邮箱及垃圾箱中的 FormSubmit 确认邮件，点击激活后再做收件测试。');
      if (result?.success !== true && result?.success !== 'true')
        throw new DeliveryError('rejected', '邮件服务未确认接受提交。请发布者检查邮箱激活状态或稍后重试。');
      return {
        status: 'accepted',
        delivered: false,
        recipient: EMAIL_DELIVERY.recipient,
        message: '邮件服务已接受提交，实际收件以 QQ 邮箱为准；首次使用仍需收件人激活确认。',
      };
    })();
    return await Promise.race([request, timeout]);
  } catch (error) {
    if (error instanceof DeliveryError) throw error;
    if (controller.signal.aborted)
      throw new DeliveryError('timeout', '发送超时，无法确认服务是否已接收。请先检查收件箱，再决定是否重试。');
    throw new DeliveryError('network', '网络连接失败，未取得发送确认。请检查网络后重试。资料仍保存在本机。');
  } finally {
    clearTimeout(timer);
  }
}
