export const preferenceKey='xindong-preferences-v1';
export const defaultPreferences=Object.freeze({theme:'acid',tone:'spicy',companion:'horse',precision:4,density:'comfortable',layout:'full',hideByDefault:false});
export const positivePresets=Object.freeze({
  confident:Object.freeze({theme:'orange',tone:'confident',companion:'horse'}),
  lamb:Object.freeze({theme:'lamb',tone:'lamb',companion:'lamb'}),
});
export function normalizePreferences(value){
  const p=value&&typeof value==='object'?value:{};
  const choose=(key,values)=>values.includes(p[key])?p[key]:defaultPreferences[key];
  return {theme:choose('theme',['acid','moss','lavender','brick','mono','orange','lamb']),tone:choose('tone',['spicy','dry','quiet','none','confident','lamb']),companion:choose('companion',['horse','lamb','none']),precision:[2,4].includes(Number(p.precision))?Number(p.precision):4,density:choose('density',['comfortable','compact']),layout:choose('layout',['full','focus']),hideByDefault:p.hideByDefault===true};
}
/** A preset changes appearance only; salary visibility and other choices stay intact. */
export function applyPositivePreset(value,preset){
  return normalizePreferences({...normalizePreferences(value),...positivePresets[preset]});
}
export function loadPreferences(storage){try{return normalizePreferences(JSON.parse(storage.getItem(preferenceKey)));}catch{return {...defaultPreferences};}}
export function roundTimeToStep(value){
  if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(value))throw new RangeError('时间格式无效');
  const [h,m]=value.split(':').map(Number),minutes=Math.round((h*60+m)/10)*10%1440;
  return `${String(Math.floor(minutes/60)).padStart(2,'0')}:${String(minutes%60).padStart(2,'0')}`;
}
export function stepTime(hour,minute){
  const h=Number(hour),m=Number(minute);
  if(!Number.isInteger(h)||h<0||h>23||![0,10,20,30,40,50,60].includes(m))throw new RangeError('请选择有效的十分钟刻度');
  return `${String((h+(m===60?1:0))%24).padStart(2,'0')}:${String(m===60?0:m).padStart(2,'0')}`;
}
