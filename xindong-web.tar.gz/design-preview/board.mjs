import {themes} from './themes.mjs';
for(const [id,t] of Object.entries(themes)){
  const card=document.createElement('a');card.className='theme-card';card.dataset.theme=id;card.href=`./?theme=${id}`;
  for(const [key,value]of Object.entries(t))if(/^#/.test(value))card.style.setProperty(`--${key}`,value);
  const marker=['orange','lamb'].includes(id)?`<img src="./assets/mascot-${t.partner}.png" alt="">`:`<span>${({acid:'NOPE',lavender:'z z z',moss:'慢'})[id]}</span>`;
  card.innerHTML=`<div class="card-top"><i></i><b>${t.name}</b><span>↗</span></div><div class="card-content"><div class="mood-marker">${marker}</div><h2>${t.headline}</h2><p>${t.greeting}</p><div class="mini-income"><span>今日计薪 · 税后估算</span><strong>¥238.16</strong><small>距离下班　04:36:46</small></div><div class="mini-bill"><span>✓ 房贷今日份额</span><span>✓ 一杯咖啡</span></div><div class="mini-dock"><img src="./assets/body-${t.partner==='lamb'?'lamb':['moss','orange'].includes(id)?'horse-calm':'horse'}.png" alt=""><div><b>敲一下</b><small>${t.effect}</small></div></div></div><div class="card-footer">${t.mood}<span>${t.effect} · 点击进入预览</span></div>`;
  document.getElementById('themeBoard').append(card);
}
