import { themes } from './themes.mjs';
const $ = id => document.getElementById(id);
let activeTheme = 'acid', count = 0, events = [], recent = [], lastTap = -Infinity;
let pending = 0, currentStrike = null, impactFrame = 0, burstFrame = 0, demoTimers = [];
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
function bodyAsset(calm=false){return `./assets/body-${themes[activeTheme].partner==='lamb'?'lamb':calm||['moss','orange'].includes(activeTheme)?'horse-calm':'horse'}.png`;}
const themeVars = {paper:'paper',surface:'surface',raised:'raised',ink:'ink',muted:'muted',line:'line',accent:'accent',accentInk:'accent-ink',cloud:'cloud'};
for (const [id,theme] of Object.entries(themes)) {
  const button = document.createElement('button'); button.type = 'button'; button.className = 'theme-choice'; button.dataset.theme = id;
  button.setAttribute('aria-pressed','false'); button.style.setProperty('--swatch',theme.accent);
  const label = document.createElement('span'), title = document.createElement('b'), subtitle = document.createElement('small');
  title.textContent=theme.name;subtitle.textContent=theme.mood;label.append(title,subtitle);button.append(label);
  button.onclick=()=>setTheme(id);document.querySelector('.theme-picker').append(button);
}
function setTheme(id) {
  activeTheme=Object.hasOwn(themes,id)?id:'acid'; const theme=themes[activeTheme];
  document.documentElement.dataset.theme=activeTheme;
  for(const [key,css] of Object.entries(themeVars))document.documentElement.style.setProperty(`--${css}`,theme[key]);
  document.querySelectorAll('.theme-choice').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.theme===activeTheme)));
  $('headline').textContent=theme.headline;$('greeting').textContent=theme.greeting;$('footerMotto').textContent=theme.greeting;
  $('heroMascot').src=`./assets/mascot-${theme.partner}.png`;$('fishBody').src=$('launcherImage').src=bodyAsset();
  const illustrated=['orange','lamb'].includes(activeTheme);$('heroMascot').hidden=!illustrated;$('mentalBadge').hidden=illustrated;
  $('mentalBadge').textContent=({acid:'NOPE',lavender:'z z z',moss:'慢'})[activeTheme]||'';
  $('launcherMood').textContent=theme.effect;$('dockTitle').textContent=theme.effect;$('contactSpark').textContent=theme.pulse;
  $('dockNote').textContent='+1 RMB 只解压，不计入收入。';
  const url=new URL(location.href);url.searchParams.set('theme',activeTheme);history.replaceState(null,'',url);
}
function openDock(open) {
  $('reliefDock').dataset.open=String(open);$('dockPanel').hidden=!open;$('dockToggle').setAttribute('aria-expanded',String(open));
  if(open)$('hitButton').focus({preventScroll:true});else $('dockToggle').focus({preventScroll:true});
}
$('dockToggle').onclick=()=>openDock(true);$('dockClose').onclick=()=>openDock(false);
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&$('reliefDock').dataset.open==='true'){openDock(false);}});
function impact() {
  if(reduced.matches){$('dockNote').textContent=`敲了一下 · 今天 ${count} 下，收入不变。`;return;}
  $('fishBody').animate([{transform:'translateY(0) scale(1)'},{transform:'translateY(3px) scale(1.035,.94)',offset:.23},{transform:'translateY(-1px) scale(.99,1.02)',offset:.6},{transform:'translateY(0) scale(1)'}],{duration:200,easing:'ease-out'});
  $('contactSpark').animate([{opacity:0,transform:'scale(.4)'},{opacity:1,transform:'scale(1.08)',offset:.2},{opacity:0,transform:'scale(1.4)'}],{duration:220,easing:'ease-out'});
  const particle=document.createElement('span');particle.className='particle';particle.textContent='+1 RMB';$('particles').append(particle);
  if($('particles').children.length>10)$('particles').firstElementChild.remove();
  particle.animate([{transform:'translate(0,0)',opacity:1},{transform:'translate(8px,-36px)',opacity:0}],{duration:650,easing:'ease-out'}).onfinish=()=>particle.remove();
}
function nextStrike() {
  if(currentStrike||!pending)return;
  pending--;
  if(reduced.matches){impact();if(pending)queueMicrotask(nextStrike);return;}
  const duration=pending>3?150:pending>0?240:420;
  const animation=$('mallet').animate([{transform:'rotate(52deg)'},{transform:'rotate(60deg)',offset:.2},{transform:'rotate(30deg)',offset:.44},{transform:'rotate(58deg)',offset:.73},{transform:'rotate(52deg)'}],{duration,easing:'linear'});
  currentStrike=animation;let impacted=false;
  const track=()=>{if(currentStrike!==animation)return;if(!impacted&&Number(animation.currentTime)>=duration*.44){impacted=true;impact();}impactFrame=requestAnimationFrame(track);};
  impactFrame=requestAnimationFrame(track);
  animation.onfinish=()=>{cancelAnimationFrame(impactFrame);if(!impacted)impact();currentStrike=null;nextStrike();};
}
function updateClouds() {
  cancelAnimationFrame(burstFrame);
  const tick=()=>{const idle=performance.now()-lastTap,alpha=Math.max(0,Math.min(1,1-(idle-3000)/9000));document.querySelector('.clouds').style.opacity=String(reduced.matches?(alpha>0?1:0):alpha);if(alpha>0)burstFrame=requestAnimationFrame(tick);else{$('toyStage').dataset.level='0';burstFrame=0;}};tick();
}
function recordTime(date){return new Intl.DateTimeFormat('zh-CN',{hour12:false,timeZone:'Asia/Shanghai',hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(date);}
function renderRecords(){const list=$('recordList');list.replaceChildren();for(const value of events.slice(-30).reverse()){const item=document.createElement('li');item.textContent=`${recordTime(value)} · 敲一下`;list.append(item);}if(!events.length){const item=document.createElement('li');item.textContent='想敲就敲，不用完成次数。';list.append(item);}}
function tap(){$('fishBody').src=bodyAsset();count++;events.push(new Date());$('tapCount').textContent=`今天敲了 ${count} 下`;$('dockNote').textContent='+1 RMB 只解压，不计入收入。';lastTap=performance.now();recent=recent.filter(t=>t>lastTap-10000);recent.push(lastTap);$('toyStage').dataset.level=String(recent.length>=10?3:recent.length>=4?2:1);updateClouds();pending++;if(currentStrike)currentStrike.playbackRate=Math.min(3,1+pending*.5);nextStrike();if(!$('recordsPanel').hidden)renderRecords();}
$('hitButton').onclick=tap;
$('clearButton').onclick=()=>{recent=[];lastTap=-Infinity;pending=0;currentStrike?.cancel();currentStrike=null;cancelAnimationFrame(impactFrame);cancelAnimationFrame(burstFrame);$('toyStage').dataset.level='0';document.querySelector('.clouds').style.opacity='0';$('particles').replaceChildren();$('dockNote').textContent=themes[activeTheme].release;$('fishBody').src=bodyAsset(true);demoTimers.forEach(clearTimeout);demoTimers=[];$('demoButton').disabled=false;};
$('demoButton').onclick=()=>{if($('demoButton').disabled)return;$('demoButton').disabled=true;for(let i=0;i<3;i++)demoTimers.push(setTimeout(tap,i*500));demoTimers.push(setTimeout(()=>{$('demoButton').disabled=false;demoTimers=[];},1500));};
$('recordsButton').onclick=()=>{const open=$('recordsPanel').hidden;$('recordsPanel').hidden=!open;$('recordsButton').setAttribute('aria-expanded',String(open));if(open)renderRecords();};
setTheme(new URLSearchParams(location.search).get('theme')||'acid');
